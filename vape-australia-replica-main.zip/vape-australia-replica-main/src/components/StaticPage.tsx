import { Link } from "@tanstack/react-router";
import pages from "@/data/pages.json";

type PageData = { title: string; html: string };
const data = pages as Record<string, PageData>;

export function getPage(slug: string): PageData | undefined {
  return data[slug];
}

export function StaticPage({ slug }: { slug: string }) {
  const page = getPage(slug);
  if (!page) {
    return (
      <main className="mx-auto max-w-[900px] px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Page not found</h1>
      </main>
    );
  }
  return (
    <main className="mx-auto max-w-[900px] px-4 py-10">
      <nav className="text-xs text-muted-foreground">
        <Link to="/" className="hover:text-sale">
          Home
        </Link>{" "}
        / <span className="text-foreground" dangerouslySetInnerHTML={{ __html: page.title }} />
      </nav>
      <h1
        className="mt-4 text-3xl font-bold"
        dangerouslySetInnerHTML={{ __html: page.title }}
      />
      <div className="wp-content mt-6" dangerouslySetInnerHTML={{ __html: page.html }} />
    </main>
  );
}
