import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { type Product } from "@/lib/catalog";
import { useCatalog } from "@/lib/db-products";
import { ProductGrid } from "@/components/ProductCard";

type Sort = "default" | "price-asc" | "price-desc" | "name";

export function CategoryPage({ slug }: { slug: string }) {
  const catalog = useCatalog();
  const cat = catalog.catBySlug.get(slug);
  const [sort, setSort] = useState<Sort>("default");
  const [page, setPage] = useState(1);
  const perPage = 24;

  if (!cat) {
    return (
      <main className="mx-auto max-w-[1280px] px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Category not found</h1>
        <Link to="/shop" className="mt-4 inline-block text-sale underline">
          Browse the shop
        </Link>
      </main>
    );
  }

  const children = catalog.childCategories(slug);
  let list: Product[] = catalog.productsInCategory(slug);
  if (sort === "price-asc") list = [...list].sort((a, b) => Number(a.price) - Number(b.price));
  if (sort === "price-desc") list = [...list].sort((a, b) => Number(b.price) - Number(a.price));
  if (sort === "name") list = [...list].sort((a, b) => a.name.localeCompare(b.name));

  const pages = Math.max(1, Math.ceil(list.length / perPage));
  const current = Math.min(page, pages);
  const shown = list.slice((current - 1) * perPage, current * perPage);

  return (
    <main className="mx-auto max-w-[1280px] px-4 py-10">
      <nav className="text-xs text-muted-foreground">
        <Link to="/" className="hover:text-sale">
          Home
        </Link>{" "}
        / <span className="text-foreground">{cat.name}</span>
      </nav>

      <h1 className="mt-4 text-center text-3xl font-bold uppercase">{cat.name}</h1>
      {cat.description ? (
        <div
          className="wp-content mx-auto mt-4 max-w-4xl text-center text-sm"
          dangerouslySetInnerHTML={{ __html: cat.description }}
        />
      ) : null}

      {children.length ? (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {children.map((c) => (
            <Link
              key={c.id}
              to={catalog.categoryPath(c)}
              className="group border border-border p-3 text-center transition-shadow hover:shadow-md"
            >
              {c.image?.src ? (
                <img
                  src={c.image.src}
                  alt={c.name}
                  loading="lazy"
                  className="aspect-square w-full object-cover"
                />
              ) : (
                <div className="aspect-square w-full bg-muted" />
              )}
              <p className="mt-2 text-xs font-semibold group-hover:text-sale">{c.name}</p>
              <p className="text-[11px] text-muted-foreground">{c.count} Products</p>
            </Link>
          ))}
        </div>
      ) : null}

      <div className="mt-10 flex items-center justify-between border-b border-border pb-3">
        <p className="text-sm text-muted-foreground">
          Showing {shown.length} of {list.length} products
        </p>
        <select
          value={sort}
          onChange={(e) => {
            setSort(e.target.value as Sort);
            setPage(1);
          }}
          className="rounded-md border border-border bg-background px-3 py-2 text-sm"
        >
          <option value="default">Default sorting</option>
          <option value="price-asc">Sort by price: low to high</option>
          <option value="price-desc">Sort by price: high to low</option>
          <option value="name">Sort by name</option>
        </select>
      </div>

      <div className="mt-8">
        <ProductGrid products={shown} />
      </div>

      {pages > 1 ? (
        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {Array.from({ length: pages }).map((_, i) => (
            <button
              key={i}
              onClick={() => {
                setPage(i + 1);
                if (typeof window !== "undefined") window.scrollTo({ top: 0 });
              }}
              className={`h-9 w-9 rounded-md border text-sm ${
                current === i + 1
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border hover:bg-accent"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      ) : null}
    </main>
  );
}
