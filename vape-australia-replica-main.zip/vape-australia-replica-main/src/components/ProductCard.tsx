import { Link } from "@tanstack/react-router";
import { ShoppingBag, Star } from "lucide-react";
import { discount, money, type Product } from "@/lib/catalog";
import { useCart } from "@/lib/cart";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const off = discount(product);
  const cat = product.cats[0]?.name ?? "";

  return (
    <div className="group relative flex flex-col text-center">
      <div className="relative overflow-hidden bg-muted">
        {off > 0 ? (
          <span className="absolute left-2 top-2 z-10 rounded-full bg-sale px-2 py-1 text-xs font-bold text-sale-foreground">
            -{off}%
          </span>
        ) : null}
        <Link to="/product/$slug" params={{ slug: product.slug }}>
          {product.image ? (
            <img
              src={product.image}
              alt={product.name}
              loading="lazy"
              className="aspect-square w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="aspect-square w-full bg-accent" />
          )}
        </Link>
        {!product.stock ? (
          <span className="absolute inset-x-0 bottom-0 bg-background/80 py-2 text-sm font-semibold uppercase">
            Out of stock
          </span>
        ) : null}
      </div>

      <p className="mt-3 text-[11px] uppercase tracking-wide text-muted-foreground">{cat}</p>
      <Link
        to="/product/$slug"
        params={{ slug: product.slug }}
        className="mt-1 px-2 text-sm font-semibold leading-snug hover:text-sale"
      >
        {product.name}
      </Link>

      <div className="mt-2 flex items-center justify-center gap-0.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={
              i < Math.round(Number(product.rating ?? 0))
                ? "h-3.5 w-3.5 fill-sale text-sale"
                : "h-3.5 w-3.5 text-border"
            }
          />
        ))}
      </div>

      <div className="mt-2 flex items-center justify-center gap-3 pb-3">
        <div className="text-sm">
          {off > 0 ? (
            <span className="mr-2 text-muted-foreground line-through">
              {money(product.regular, product.md)}
            </span>
          ) : null}
          <span className="font-bold text-sale">{money(product.price, product.md)}</span>
        </div>
        {product.stock ? (
          <button
            aria-label={`Add ${product.name} to cart`}
            onClick={() => add(product.slug)}
            className="rounded-full border border-border p-2 transition-colors hover:bg-primary hover:text-primary-foreground"
          >
            <ShoppingBag className="h-4 w-4" />
          </button>
        ) : null}
      </div>
    </div>
  );
}

export function ProductGrid({ products }: { products: Product[] }) {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {products.map((p) => (
        <ProductCard key={p.slug} product={p} />
      ))}
    </div>
  );
}
