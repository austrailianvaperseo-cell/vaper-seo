import { Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Facebook,
  Instagram,
  Linkedin,
  Youtube,
  Twitter,
  Mail,
  MapPin,
  Send,
  Phone,
  MessageCircle,
  LifeBuoy,
} from "lucide-react";
import { footerColumns, socials } from "@/lib/site";
import { useSettings } from "@/lib/settings";

const icons: Record<string, typeof Facebook> = {
  Facebook,
  Instagram,
  X: Twitter,
  LinkedIn: Linkedin,
  YouTube: Youtube,
};

export function Footer() {
  const [order, setOrder] = useState("");
  const [msg, setMsg] = useState("");
  const settings = useSettings();

  return (
    <footer className="mt-16 bg-topbar text-topbar-foreground">
      <div className="mx-auto grid max-w-[1280px] gap-10 px-4 py-14 md:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <img
            src={settings.logo_url}
            alt={settings.site_name}
            className="h-11 w-auto brightness-0 invert"
          />
          <p className="mt-4 max-w-md text-sm leading-relaxed opacity-80">
            Australia's reliable online vape shop offers authentic disposable vapes and nicotine
            pouches. We provide adults across Australia a safe and trustworthy way to purchase
            genuine products online.
          </p>
          <p className="mt-4 flex items-center gap-2 text-sm opacity-80">
            <MapPin className="h-4 w-4" /> {settings.address}
          </p>
          <a
            href={`mailto:${settings.contact_email}`}
            className="mt-2 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
          >
            <Mail className="h-4 w-4" /> {settings.contact_email}
          </a>
          {settings.support_email && settings.support_email !== settings.contact_email ? (
            <a
              href={`mailto:${settings.support_email}`}
              className="mt-2 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
            >
              <LifeBuoy className="h-4 w-4" /> {settings.support_email}
            </a>
          ) : null}
          {settings.phone ? (
            <a
              href={`tel:${settings.phone}`}
              className="mt-2 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
            >
              <Phone className="h-4 w-4" /> {settings.phone}
            </a>
          ) : null}
          {settings.telegram_channel_url ? (
            <a
              href={settings.telegram_channel_url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
            >
              <Send className="h-4 w-4" /> Telegram channel
            </a>
          ) : null}
          {settings.telegram_url ? (
            <a
              href={settings.telegram_url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
            >
              <Send className="h-4 w-4" /> Telegram support
            </a>
          ) : null}
          {settings.whatsapp_url ? (
            <a
              href={settings.whatsapp_url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp
            </a>
          ) : null}
          <div className="mt-5 flex gap-3">
            {socials.map((s) => {
              const Icon = icons[s.label] ?? Facebook;
              return (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-white/25 p-2 transition-colors hover:bg-white/10"
                >
                  <Icon className="h-4 w-4" />
                </a>
              );
            })}
          </div>
        </div>

        {footerColumns.map((col) => (
          <div key={col.title}>
            <h3 className="text-sm font-bold uppercase tracking-wide">{col.title}</h3>
            <ul className="mt-4 space-y-2 text-sm opacity-80">
              {col.links.map((l) => (
                <li key={l.href}>
                  <Link to={l.href} className="hover:opacity-100 hover:underline">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
            {col.title === "Support" ? (
              <form
                className="mt-4 flex"
                onSubmit={(e) => {
                  e.preventDefault();
                  setMsg(
                    order
                      ? `We couldn't find live tracking for order #${order}. Tracking details are emailed once dispatched.`
                      : "Please enter an order number.",
                  );
                }}
              >
                <input
                  value={order}
                  onChange={(e) => setOrder(e.target.value)}
                  placeholder="Order number"
                  className="w-full rounded-l-md bg-white/10 px-3 py-2 text-xs outline-none placeholder:text-white/50"
                />
                <button className="rounded-r-md bg-sale px-3 py-2 text-xs font-bold text-sale-foreground">
                  TRACK
                </button>
              </form>
            ) : null}
            {col.title === "Support" && msg ? (
              <p className="mt-2 text-xs opacity-80">{msg}</p>
            ) : null}
          </div>
        ))}
      </div>

      <div className="border-t border-white/15">
        <div className="mx-auto max-w-[1280px] px-4 py-6 text-center text-xs opacity-80">
          <p>Copyright 2025 ©{settings.site_name.toUpperCase()}. All rights reserved.</p>
          <p className="mt-2">
            <Link to="/privacy-policy" className="hover:underline">
              Privacy Policy
            </Link>
            {" | "}
            <Link to="/terms-conditions" className="hover:underline">
              Terms and Conditions
            </Link>
            {" | "}
            <Link to="/legal-and-medical-disclaimer" className="hover:underline">
              Disclaimer
            </Link>
          </p>
          <p className="mx-auto mt-4 max-w-3xl">
            WARNING: Some products may contain nicotine, which is addictive. Not suitable for
            minors, non-smokers, or pregnant or breastfeeding individuals. Use in accordance with
            Australian law.
          </p>
          <p className="mt-4 font-semibold">MasterCard · Visa · American Express</p>
        </div>
      </div>
    </footer>
  );
}
