import { useEffect, useState } from "react";
import { Send } from "lucide-react";
import { site } from "@/lib/site";
import { useSettings } from "@/lib/settings";

export function AgeGate() {
  const [show, setShow] = useState(false);
  const [declined, setDeclined] = useState(false);
  const settings = useSettings();
  const telegram = settings.telegram_channel_url || settings.telegram_url;

  useEffect(() => {
    try {
      if (!sessionStorage.getItem("av-age-ok")) setShow(true);
    } catch {
      setShow(true);
    }
  }, []);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-black/85 px-3 py-6 sm:items-center sm:px-4">
      <div className="my-auto w-full max-w-xl rounded-lg bg-background p-5 text-center shadow-2xl sm:p-8">
        <img src={site.logo} alt="Australian Vapers" className="mx-auto h-9 w-auto sm:h-12" />
        {declined ? (
          <>
            <h2 className="mt-5 text-xl font-bold sm:mt-6 sm:text-2xl">Come back when you're 18</h2>
            <p className="mt-3 text-sm text-muted-foreground">
              You must be at least 18 years old to browse this store.
            </p>
          </>
        ) : (
          <>
            <h2 className="mt-5 text-2xl font-bold sm:mt-6 sm:text-4xl">Are you over 18?</h2>
            <p className="mt-3 text-xs text-muted-foreground sm:text-sm">
              All purchasers before order placement are digitally age-verified. In certain states,
              adult signature upon delivery will be required.
            </p>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:mt-7 sm:flex-row sm:flex-wrap sm:gap-4">
              <button
                onClick={() => {
                  try {
                    sessionStorage.setItem("av-age-ok", "1");
                  } catch {
                    /* ignore */
                  }
                  setShow(false);
                }}
                className="w-full rounded-md bg-success px-6 py-3 text-success-foreground sm:w-auto sm:px-8"
              >
                <span className="block text-base font-bold">Yes, I am over 18</span>
                <span className="block text-xs opacity-90">
                  I understand my age will be verified
                </span>
              </button>
              <button
                onClick={() => setDeclined(true)}
                className="w-full rounded-md border-2 border-sale px-6 py-3 text-foreground sm:w-auto sm:px-8"
              >
                <span className="block text-base font-bold">No,</span>
                <span className="block text-xs text-muted-foreground">I'll come back later</span>
              </button>
            </div>
            {telegram ? (
              <a
                href={telegram}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-bold text-primary-foreground hover:opacity-90 sm:mt-5 sm:w-auto"
              >
                <Send className="h-4 w-4" /> Join our Telegram channel
              </a>
            ) : null}
            <p className="mt-5 text-[10px] uppercase leading-relaxed text-muted-foreground sm:mt-7 sm:text-[11px]">
              State law prohibits the sale of our products or electronic smoking devices and
              nicotine pouches to persons under the age of eighteen (18) years. Proof of age
              required. Anyone who sells or distributes our products or electronic smoking devices
              to a person under the age of eighteen (18) years is subject to strict fines and
              penalties. Persons under the age of eighteen (18) years are subject to fines and
              penalties.
            </p>
            <p className="mt-3 text-xs text-muted-foreground">
              We ship to all states except where prohibited by law.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
