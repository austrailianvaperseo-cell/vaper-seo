import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Search, User, ShoppingBag, ChevronDown, Menu, X } from "lucide-react";
import { nav, site } from "@/lib/site";
import { useCart } from "@/lib/cart";
import { useSettings } from "@/lib/settings";

export function Header() {
  const settings = useSettings();
  const { count, total } = useCart();
  const [open, setOpen] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [q, setQ] = useState("");
  const navigate = useNavigate();

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    setShowSearch(false);
    navigate({ to: "/shop", search: { s: q } });
  }

  return (
    <header className="sticky top-0 z-40 bg-background shadow-sm">
      <div className="bg-topbar py-2 text-center text-xs text-topbar-foreground">
        {site.topBar}
      </div>
      <div className="mx-auto flex max-w-[1280px] items-center gap-4 px-4 py-3">
        <Link to="/" className="shrink-0">
          <img src={settings.logo_url} alt={settings.site_name} className="h-10 w-auto" />
        </Link>

        <nav className="ml-6 hidden flex-1 items-center gap-7 lg:flex">
          {nav.map((item) => (
            <div key={item.href} className="group relative">
              <Link
                to={item.href}
                className="flex items-center gap-1 text-[15px] font-semibold text-foreground transition-colors hover:text-sale"
              >
                {item.label}
                {item.children ? <ChevronDown className="h-3.5 w-3.5" /> : null}
                {item.tag ? (
                  <span className="ml-1 rounded-sm bg-sale px-1 py-0.5 text-[9px] font-bold text-sale-foreground">
                    {item.tag}
                  </span>
                ) : null}
              </Link>
              {item.children ? (
                <div className="invisible absolute left-0 top-full z-50 w-72 translate-y-1 border border-border bg-popover py-2 opacity-0 shadow-lg transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                  {item.children.map((c) => (
                    <Link
                      key={c.href}
                      to={c.href}
                      className="block px-4 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground hover:bg-accent hover:text-foreground"
                    >
                      {c.label}
                    </Link>
                  ))}
                </div>
              ) : null}
            </div>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <button
            aria-label="Search"
            onClick={() => setShowSearch((s) => !s)}
            className="rounded-md border border-border p-2 text-foreground hover:bg-accent"
          >
            <Search className="h-4 w-4" />
          </button>
          <Link
            to="/my-account"
            aria-label="My account"
            className="rounded-md border border-border p-2 text-foreground hover:bg-accent"
          >
            <User className="h-4 w-4" />
          </Link>
          <Link
            to="/cart"
            className="flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-semibold text-foreground hover:bg-accent"
          >
            ${total.toFixed(2)}
            <span className="relative">
              <ShoppingBag className="h-4 w-4" />
              {count > 0 ? (
                <span className="absolute -right-2 -top-2 rounded-full bg-sale px-1 text-[10px] font-bold text-sale-foreground">
                  {count}
                </span>
              ) : null}
            </span>
          </Link>
          <button
            aria-label="Menu"
            className="rounded-md border border-border p-2 lg:hidden"
            onClick={() => setOpen((o) => !o)}
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {showSearch ? (
        <form onSubmit={submitSearch} className="border-t border-border bg-muted px-4 py-3">
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search for products…"
            className="mx-auto block w-full max-w-2xl rounded-md border border-border bg-background px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        </form>
      ) : null}

      {open ? (
        <div className="border-t border-border bg-background px-4 pb-4 lg:hidden">
          {nav.map((item) => (
            <div key={item.href} className="border-b border-border py-2">
              <Link
                to={item.href}
                onClick={() => setOpen(false)}
                className="block text-sm font-semibold"
              >
                {item.label}
              </Link>
              {item.children?.map((c) => (
                <Link
                  key={c.href}
                  to={c.href}
                  onClick={() => setOpen(false)}
                  className="block py-1 pl-3 text-xs uppercase text-muted-foreground"
                >
                  {c.label}
                </Link>
              ))}
            </div>
          ))}
          <Link to="/shop" onClick={() => setOpen(false)} className="block py-2 text-sm font-semibold">
            Shop All
          </Link>
        </div>
      ) : null}
    </header>
  );
}
