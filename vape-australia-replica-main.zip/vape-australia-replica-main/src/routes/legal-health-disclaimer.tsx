import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/legal-health-disclaimer")({
  head: () => ({
    meta: [
      { title: "Legal Health Disclaimer | Australian Vapers" },
      { name: "description", content: "Health disclaimer for nicotine vaping products sold to adults in Australia." },
      { property: "og:title", content: "Legal Health Disclaimer | Australian Vapers" },
      { property: "og:description", content: "Health information for adult nicotine product users." },
    ],
  }),
  component: () => <StaticPage slug="legal-health-disclaimer" />,
});
