import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Star } from "lucide-react";
import { bySlug, discount, money } from "@/lib/catalog";
import { useCart } from "@/lib/cart";
import { ProductGrid } from "@/components/ProductCard";
import { supabase } from "@/integrations/supabase/client";
import { toCatalogProduct, useCatalog, type DbProduct } from "@/lib/db-products";

type Detail = { short: string; desc: string; images: string[] };
const detailFiles = import.meta.glob<{ default: Detail }>("../data/details/*.json");

async function loadDetail(slug: string): Promise<Detail | undefined> {
  const key = Object.keys(detailFiles).find((k) => k.endsWith(`/${slug}.json`));
  if (!key) return undefined;
  const mod = await detailFiles[key]!();
  return mod.default;
}

export const Route = createFileRoute("/product/$slug")({
  loader: async ({ params }) => {
    const product = bySlug.get(params.slug);
    if (!product) {
      const { data } = await supabase
        .from("products")
        .select("*")
        .eq("slug", params.slug)
        .eq("hidden", false)
        .maybeSingle();
      if (!data) throw notFound();
      const row = data as DbProduct;
      return {
        name: row.name,
        image: row.image,
        detail: { short: "", desc: row.description ?? "", images: row.image ? [row.image] : [] },
        custom: row,
      };
    }
    const detail = await loadDetail(params.slug);
    return { name: product.name, image: product.image, detail, custom: null };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Product unavailable | Australian Vapers" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.name} | Australian Vapers`;
    const description = `Buy ${loaderData.name} online in Australia. Genuine, factory-sealed stock with fast Australia-wide delivery.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        ...(loaderData.image
          ? [
              { property: "og:image", content: loaderData.image },
              { name: "twitter:image", content: loaderData.image },
            ]
          : []),
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const { detail, custom } = Route.useLoaderData();
  const catalog = useCatalog();
  const fallback = bySlug.get(slug) ?? (custom ? toCatalogProduct(custom) : undefined);
  const product = catalog.bySlug.get(slug) ?? fallback;
  const { add } = useCart();
  const [qty, setQty] = useState(1);
  const [active, setActive] = useState(0);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <main className="mx-auto max-w-[1280px] px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Product not found</h1>
        <Link to="/shop" className="mt-4 inline-block text-sale underline">
          Browse the shop
        </Link>
      </main>
    );
  }

  const images = product.images?.length
    ? product.images
    : detail?.images?.length
      ? detail.images
      : product.image
        ? [product.image]
        : [];
  const shortHtml = detail?.short ?? "";
  const descHtml = detail?.desc || (product.description ?? "");
  const off = discount(product);
  const mainCat = product.cats.find((c) => catalog.catBySlug.get(c.slug));
  const related = mainCat
    ? catalog.productsInCategory(mainCat.slug)
        .filter((p) => p.slug !== slug)
        .slice(0, 5)
    : [];

  return (
    <main className="mx-auto max-w-[1280px] px-4 py-10">
      <nav className="text-xs text-muted-foreground">
        <Link to="/" className="hover:text-sale">
          Home
        </Link>
        {mainCat && catalog.catBySlug.get(mainCat.slug) ? (
          <>
            {" / "}
            <Link to={catalog.categoryPath(catalog.catBySlug.get(mainCat.slug)!)} className="hover:text-sale">
              {mainCat.name}
            </Link>
          </>
        ) : null}
        {" / "}
        <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        <div>
          {images[active] ? (
            <img
              src={images[active]}
              alt={product.name}
              className="w-full border border-border object-cover"
            />
          ) : null}
          {images.length > 1 ? (
            <div className="mt-3 flex gap-3">
              {images.map((img, i) => (
                <button
                  key={img}
                  onClick={() => setActive(i)}
                  className={`h-20 w-20 border ${i === active ? "border-sale" : "border-border"}`}
                >
                  <img src={img} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          ) : null}
        </div>

        <div>
          <h1 className="text-2xl font-bold md:text-3xl">{product.name}</h1>
          <div className="mt-3 flex items-center gap-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={
                  i < Math.round(Number(product.rating ?? 0))
                    ? "h-4 w-4 fill-sale text-sale"
                    : "h-4 w-4 text-border"
                }
              />
            ))}
            <span className="text-xs text-muted-foreground">({product.count} reviews)</span>
          </div>

          <div className="mt-4 flex items-center gap-3">
            {off > 0 ? (
              <span className="text-lg text-muted-foreground line-through">
                {money(product.regular, product.md)}
              </span>
            ) : null}
            <span className="text-3xl font-bold text-sale">{money(product.price, product.md)}</span>
            {off > 0 ? (
              <span className="rounded-full bg-sale px-2 py-1 text-xs font-bold text-sale-foreground">
                -{off}%
              </span>
            ) : null}
          </div>

          <p className="mt-3 text-sm font-semibold">
            {product.stock ? (
              <span className="text-success">In stock</span>
            ) : (
              <span className="text-sale">Out of stock</span>
            )}
          </p>

          {shortHtml ? (
            <div className="wp-content mt-5 text-sm" dangerouslySetInnerHTML={{ __html: shortHtml }} />
          ) : null}
          {product.flavors?.length ? (
            <div className="mt-5">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Flavours
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {product.flavors.map((f) => (
                  <span key={f} className="rounded-full border border-border px-3 py-1 text-xs">
                    {f}
                  </span>
                ))}
              </div>
            </div>
          ) : null}

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <div className="flex items-center border border-border">
              <button
                className="px-3 py-2 text-lg"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                aria-label="Decrease quantity"
              >
                −
              </button>
              <span className="w-10 text-center text-sm">{qty}</span>
              <button
                className="px-3 py-2 text-lg"
                onClick={() => setQty((q) => q + 1)}
                aria-label="Increase quantity"
              >
                +
              </button>
            </div>
            <button
              disabled={!product.stock}
              onClick={() => {
                add(product.slug, qty);
                setAdded(true);
              }}
              className="rounded-md bg-primary px-8 py-3 text-sm font-bold uppercase text-primary-foreground disabled:opacity-50"
            >
              Add to cart
            </button>
            {added ? (
              <Link to="/cart" className="text-sm font-semibold text-sale underline">
                View cart
              </Link>
            ) : null}
          </div>

          <p className="mt-6 text-xs text-muted-foreground">
            Categories:{" "}
            {product.cats.map((c, i) => (
              <span key={c.slug}>
                {i > 0 ? ", " : ""}
                {catalog.catBySlug.get(c.slug) ? (
                  <Link to={catalog.categoryPath(catalog.catBySlug.get(c.slug)!)} className="hover:text-sale">
                    {c.name}
                  </Link>
                ) : (
                  c.name
                )}
              </span>
            ))}
          </p>
        </div>
      </div>

      {descHtml ? (
        <section className="mt-14">
          <h2 className="border-b border-border pb-3 text-lg font-bold uppercase">Description</h2>
          <div className="wp-content mt-6" dangerouslySetInnerHTML={{ __html: descHtml }} />
        </section>
      ) : null}

      {related.length ? (
        <section className="mt-14">
          <h2 className="text-center text-2xl font-bold uppercase">Related Products</h2>
          <div className="mt-8">
            <ProductGrid products={related} />
          </div>
        </section>
      ) : null}
    </main>
  );
}
