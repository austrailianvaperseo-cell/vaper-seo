import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/product-evaluation-process")({
  head: () => ({
    meta: [
      { title: "Product Evaluation Process | Australian Vapers" },
      { name: "description", content: "How we test, review and approve every vape and nicotine pouch we stock." },
      { property: "og:title", content: "Product Evaluation Process | Australian Vapers" },
      { property: "og:description", content: "Our quality control and product testing standards." },
    ],
  }),
  component: () => <StaticPage slug="product-evaluation-process" />,
});
