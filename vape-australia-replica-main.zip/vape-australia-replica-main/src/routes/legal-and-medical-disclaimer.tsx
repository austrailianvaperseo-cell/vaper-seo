import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/legal-and-medical-disclaimer")({
  head: () => ({
    meta: [
      { title: "Legal & Medical Disclaimer | Australian Vapers" },
      { name: "description", content: "Legal and medical disclaimer covering nicotine products sold by Australian Vapers." },
      { property: "og:title", content: "Legal & Medical Disclaimer | Australian Vapers" },
      { property: "og:description", content: "Important legal and health information for adult users." },
    ],
  }),
  component: () => <StaticPage slug="legal-and-medical-disclaimer" />,
});
