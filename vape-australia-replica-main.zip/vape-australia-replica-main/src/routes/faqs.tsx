import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/faqs")({
  head: () => ({
    meta: [
      { title: "FAQs | Australian Vapers" },
      { name: "description", content: "Answers to common questions about shipping, payments, authenticity and returns at Australian Vapers." },
      { property: "og:title", content: "FAQs | Australian Vapers" },
      { property: "og:description", content: "Shipping, payment, authenticity and returns questions answered." },
    ],
  }),
  component: () => <StaticPage slug="faqs" />,
});
