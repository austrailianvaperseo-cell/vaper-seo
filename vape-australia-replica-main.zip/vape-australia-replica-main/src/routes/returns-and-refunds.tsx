import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/returns-and-refunds")({
  head: () => ({
    meta: [
      { title: "Returns & Refunds Policy | Australian Vapers" },
      { name: "description", content: "How to report a faulty or damaged vape and request a replacement or store credit." },
      { property: "og:title", content: "Returns & Refunds Policy | Australian Vapers" },
      { property: "og:description", content: "Our returns, replacements and refunds process." },
    ],
  }),
  component: () => <StaticPage slug="returns-and-refunds" />,
});
