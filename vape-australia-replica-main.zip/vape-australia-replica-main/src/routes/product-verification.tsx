import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/product-verification")({
  head: () => ({
    meta: [
      { title: "Product Verification | Australian Vapers" },
      { name: "description", content: "How to verify the authenticity of vapes and nicotine pouches bought from Australian Vapers." },
      { property: "og:title", content: "Product Verification | Australian Vapers" },
      { property: "og:description", content: "Check that your device is genuine, factory-sealed stock." },
    ],
  }),
  component: () => <StaticPage slug="product-verification" />,
});
