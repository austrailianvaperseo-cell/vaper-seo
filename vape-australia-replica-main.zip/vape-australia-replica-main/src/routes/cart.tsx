import { createFileRoute, Link } from "@tanstack/react-router";
import { useCart } from "@/lib/cart";
import { money } from "@/lib/catalog";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart | Australian Vapers" },
      { name: "description", content: "Review the vapes and nicotine pouches in your cart before checkout." },
      { property: "og:title", content: "Your Cart | Australian Vapers" },
      { property: "og:description", content: "Review your Australian Vapers order before checkout." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, total } = useCart();

  if (!items.length) {
    return (
      <main className="mx-auto max-w-[900px] px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Your cart is currently empty</h1>
        <Link
          to="/shop"
          className="mt-6 inline-block rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
        >
          Return to shop
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-[1100px] px-4 py-10">
      <h1 className="text-3xl font-bold">Cart</h1>
      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_320px]">
        <div className="divide-y divide-border border-y border-border">
          {items.map(({ product, qty }) => (
            <div key={product.slug} className="flex gap-4 py-4">
              {product.image ? (
                <img src={product.image} alt="" className="h-24 w-24 object-cover" />
              ) : null}
              <div className="flex-1">
                <Link
                  to="/product/$slug"
                  params={{ slug: product.slug }}
                  className="text-sm font-semibold hover:text-sale"
                >
                  {product.name}
                </Link>
                <p className="mt-1 text-sm text-sale">{money(product.price, product.md)}</p>
                <div className="mt-2 flex items-center gap-3">
                  <div className="flex items-center border border-border">
                    <button className="px-2 py-1" onClick={() => setQty(product.slug, qty - 1)}>
                      −
                    </button>
                    <span className="w-8 text-center text-sm">{qty}</span>
                    <button className="px-2 py-1" onClick={() => setQty(product.slug, qty + 1)}>
                      +
                    </button>
                  </div>
                  <button
                    className="text-xs text-muted-foreground underline"
                    onClick={() => remove(product.slug)}
                  >
                    Remove
                  </button>
                </div>
              </div>
              <div className="text-sm font-bold">
                ${((Number(product.price) / 100) * qty).toFixed(2)}
              </div>
            </div>
          ))}
        </div>

        <aside className="h-fit border border-border p-6">
          <h2 className="text-lg font-bold">Cart totals</h2>
          <div className="mt-4 flex justify-between text-sm">
            <span>Subtotal</span>
            <span>${total.toFixed(2)}</span>
          </div>
          <div className="mt-2 flex justify-between text-sm text-muted-foreground">
            <span>Shipping</span>
            <span>Calculated at checkout</span>
          </div>
          <div className="mt-4 flex justify-between border-t border-border pt-4 text-base font-bold">
            <span>Total</span>
            <span className="text-sale">${total.toFixed(2)}</span>
          </div>
          <Link
            to="/checkout"
            className="mt-6 block rounded-md bg-primary py-3 text-center text-sm font-bold uppercase text-primary-foreground"
          >
            Proceed to checkout
          </Link>
        </aside>
      </div>
    </main>
  );
}
