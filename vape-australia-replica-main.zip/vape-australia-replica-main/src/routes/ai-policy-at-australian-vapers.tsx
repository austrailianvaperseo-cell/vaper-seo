import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/ai-policy-at-australian-vapers")({
  head: () => ({
    meta: [
      { title: "AI Policy | Australian Vapers" },
      { name: "description", content: "How Australian Vapers uses AI tools responsibly across content and customer support." },
      { property: "og:title", content: "AI Policy | Australian Vapers" },
      { property: "og:description", content: "Our responsible AI usage policy." },
    ],
  }),
  component: () => <StaticPage slug="ai-policy-at-australian-vapers" />,
});
