import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";
import { catBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/nicotine-pouches/$")({
  loader: ({ params }) => {
    const slug = params._splat?.split("/").filter(Boolean).pop() ?? "nicotine-pouches";
    const cat = catBySlug.get(slug);
    return { slug, name: cat?.name ?? "Nicotine Pouches" };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.name ?? "Nicotine Pouches";
    const title = `${name} | Australian Vapers`;
    const description = `Buy ${name} online in Australia with genuine stock and fast, discreet nationwide delivery.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
    };
  },
  component: PouchCategory,
});

function PouchCategory() {
  const { slug } = Route.useLoaderData();
  return <CategoryPage slug={slug} />;
}
