import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useCart } from "@/lib/cart";
import { usePaymentMethods } from "@/lib/payment-methods";
import { createOrder } from "@/lib/orders";
import { sendOrderEmails } from "@/lib/order-emails.functions";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout | Australian Vapers" },
      { name: "description", content: "Secure checkout for your Australian Vapers order." },
      { property: "og:title", content: "Checkout | Australian Vapers" },
      { property: "og:description", content: "Complete your order with secure, discreet delivery." },
    ],
  }),
  component: Checkout,
});

const field =
  "mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-ring";

function Checkout() {
  const { items, total, clear } = useCart();
  const methods = usePaymentMethods();
  const [pay, setPay] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  if (done) {
    return (
      <main className="mx-auto max-w-[700px] px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Thank you. Your order has been received.</h1>
        <p className="mt-4 text-sm text-muted-foreground">
          Order number <strong className="text-foreground">{done}</strong>. We'll email your
          tracking details once your parcel is dispatched with Australia Post.
        </p>
        <Link to="/shop" className="mt-6 inline-block text-sm font-semibold text-sale underline">
          Continue shopping
        </Link>
      </main>
    );
  }

  if (!items.length) {
    return (
      <main className="mx-auto max-w-[900px] px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Your cart is empty</h1>
        <Link to="/shop" className="mt-6 inline-block text-sm font-semibold text-sale underline">
          Return to shop
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-[1100px] px-4 py-10">
      <h1 className="text-3xl font-bold">Checkout</h1>
      <form
        className="mt-8 grid gap-10 lg:grid-cols-[1fr_360px]"
        onSubmit={async (e) => {
          e.preventDefault();
          if (saving) return;
          const f = new FormData(e.currentTarget);
          const get = (k: string) => String(f.get(k) ?? "").trim();
          const num = "AV" + Math.floor(100000 + Math.random() * 899999);
          const method = methods.find((m) => m.id === (pay ?? methods[0]?.id));
          setSaving(true);
          setErr(null);
          try {
            await createOrder({
              order_number: num,
              customer_name: `${get("first_name")} ${get("last_name")}`.trim(),
              email: get("email"),
              phone: get("phone"),
              address: get("address"),
              suburb: get("suburb"),
              state: get("state"),
              postcode: get("postcode"),
              notes: get("notes"),
              payment_method: method?.name ?? "",
              items: items.map(({ product, qty }) => ({
                slug: product.slug,
                name: product.name,
                qty,
                price: Number(product.price) / 100,
              })),
              total: Number(total.toFixed(2)),
            });
            try {
              await sendOrderEmails({ data: { orderNumber: num } });
            } catch {
              /* order is saved; email delivery is best-effort */
            }
            clear();
            setDone(num);
          } catch {
            setErr("We couldn't place your order. Please check your details and try again.");
          } finally {
            setSaving(false);
          }
        }}
      >
        <div>
          <h2 className="text-lg font-bold">Billing details</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <label className="text-sm">
              First name *<input name="first_name" required className={field} />
            </label>
            <label className="text-sm">
              Last name *<input name="last_name" required className={field} />
            </label>
            <label className="text-sm sm:col-span-2">
              Street address *<input name="address" required className={field} />
            </label>
            <label className="text-sm">
              Suburb *<input name="suburb" required className={field} />
            </label>
            <label className="text-sm">
              State *<input name="state" required className={field} />
            </label>
            <label className="text-sm">
              Postcode *<input name="postcode" required className={field} />
            </label>
            <label className="text-sm">
              Phone *<input name="phone" required type="tel" className={field} />
            </label>
            <label className="text-sm sm:col-span-2">
              Email address *<input name="email" required type="email" className={field} />
            </label>
            <label className="text-sm sm:col-span-2">
              Order notes (optional)
              <textarea name="notes" rows={3} className={field} />
            </label>
          </div>
        </div>

        <aside className="h-fit border border-border p-6">
          <h2 className="text-lg font-bold">Your order</h2>
          <div className="mt-4 divide-y divide-border text-sm">
            {items.map(({ product, qty }) => (
              <div key={product.slug} className="flex justify-between gap-4 py-2">
                <span>
                  {product.name} × {qty}
                </span>
                <span>${((Number(product.price) / 100) * qty).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 flex justify-between border-t border-border pt-4 text-base font-bold">
            <span>Total</span>
            <span className="text-sale">${total.toFixed(2)}</span>
          </div>
          <fieldset className="mt-5 space-y-3 text-sm">
            <legend className="font-semibold">Payment method</legend>
            {methods.length ? (
              methods.map((m, i) => (
                <label key={m.id} className="block">
                  <span className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="pay"
                      defaultChecked={i === 0}
                      onChange={() => setPay(m.id)}
                    />
                    {m.name}
                  </span>
                  {m.description ? (
                    <span className="ml-6 block text-xs text-muted-foreground">
                      {m.description}
                    </span>
                  ) : null}
                  {(pay ?? methods[0]?.id) === m.id && m.instructions ? (
                    <span className="ml-6 mt-1 block whitespace-pre-line text-xs text-muted-foreground">
                      {m.instructions}
                    </span>
                  ) : null}
                </label>
              ))
            ) : (
              <p className="text-xs text-muted-foreground">No payment methods available.</p>
            )}
          </fieldset>
          {err ? <p className="mt-4 text-xs font-semibold text-destructive">{err}</p> : null}
          <button
            disabled={saving}
            className="mt-6 w-full rounded-md bg-primary py-3 text-sm font-bold uppercase text-primary-foreground disabled:opacity-60"
          >
            {saving ? "Placing order…" : "Place order"}
          </button>
        </aside>
      </form>
    </main>
  );
}
