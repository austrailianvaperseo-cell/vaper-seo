import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/my-account")({
  head: () => ({
    meta: [
      { title: "My Account | Australian Vapers" },
      { name: "description", content: "Log in to your Australian Vapers account to view orders and track deliveries." },
      { property: "og:title", content: "My Account | Australian Vapers" },
      { property: "og:description", content: "Access your Australian Vapers orders and details." },
    ],
  }),
  component: Account,
});

const field =
  "mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-ring";

function Account() {
  return (
    <main className="mx-auto max-w-[900px] px-4 py-12">
      <h1 className="text-3xl font-bold">My account</h1>
      <div className="mt-8 grid gap-10 md:grid-cols-2">
        <form className="border border-border p-6" onSubmit={(e) => e.preventDefault()}>
          <h2 className="text-lg font-bold">Login</h2>
          <label className="mt-4 block text-sm">
            Username or email *<input required className={field} />
          </label>
          <label className="mt-4 block text-sm">
            Password *<input required type="password" className={field} />
          </label>
          <button className="mt-5 rounded-md bg-primary px-6 py-2.5 text-sm font-bold uppercase text-primary-foreground">
            Log in
          </button>
        </form>
        <form className="border border-border p-6" onSubmit={(e) => e.preventDefault()}>
          <h2 className="text-lg font-bold">Register</h2>
          <label className="mt-4 block text-sm">
            Email address *<input required type="email" className={field} />
          </label>
          <label className="mt-4 block text-sm">
            Password *<input required type="password" className={field} />
          </label>
          <p className="mt-3 text-xs text-muted-foreground">
            Your personal data will be used to support your experience throughout this website and
            to manage access to your account.
          </p>
          <button className="mt-5 rounded-md bg-primary px-6 py-2.5 text-sm font-bold uppercase text-primary-foreground">
            Register
          </button>
        </form>
      </div>
    </main>
  );
}
