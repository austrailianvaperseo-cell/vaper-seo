import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/shipping-policy")({
  head: () => ({
    meta: [
      { title: "Shipping Policy | Australian Vapers" },
      { name: "description", content: "Delivery times, discreet packaging and Australia Post tracking for every Australian Vapers order." },
      { property: "og:title", content: "Shipping Policy | Australian Vapers" },
      { property: "og:description", content: "How and when we ship your vape order across Australia." },
    ],
  }),
  component: () => <StaticPage slug="shipping-policy" />,
});
