import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/delivery-locations")({
  head: () => ({
    meta: [
      { title: "Delivery Locations | Australian Vapers" },
      { name: "description", content: "Where we deliver across Australia, from metro capitals to regional postcodes." },
      { property: "og:title", content: "Delivery Locations | Australian Vapers" },
      { property: "og:description", content: "Australia-wide delivery coverage and timeframes." },
    ],
  }),
  component: () => <StaticPage slug="delivery-locations" />,
});
