import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/payment-methods")({
  head: () => ({
    meta: [
      { title: "Payment Methods | Australian Vapers" },
      { name: "description", content: "Accepted payment methods at Australian Vapers, including bank transfer and Visa/Mastercard." },
      { property: "og:title", content: "Payment Methods | Australian Vapers" },
      { property: "og:description", content: "Secure ways to pay for your vape order." },
    ],
  }),
  component: () => <StaticPage slug="payment-methods" />,
});
