import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Our Team | Australian Vapers" },
      { name: "description", content: "Meet the team behind Australian Vapers and our product evaluation standards." },
      { property: "og:title", content: "Our Team | Australian Vapers" },
      { property: "og:description", content: "The people behind Australia's trusted online vape store." },
    ],
  }),
  component: () => <StaticPage slug="team" />,
});
