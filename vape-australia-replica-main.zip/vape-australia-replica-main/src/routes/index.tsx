import { createFileRoute, Link } from "@tanstack/react-router";
import { badges, homeFaqs, reviews, site } from "@/lib/site";
import { homeSections } from "@/lib/catalog";
import { useCatalog } from "@/lib/db-products";
import { ProductGrid } from "@/components/ProductCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "Australian Vapers | Disposable Vapes & Nicotine Pouches Online",
      },
      {
        name: "description",
        content:
          "Buy authentic disposable vapes and nicotine pouches in Australia. IGET, ALIBARBAR, GUNNPOD, HQD and more with fast Australia-wide delivery.",
      },
      {
        property: "og:title",
        content: "Australian Vapers | Disposable Vapes & Nicotine Pouches Online",
      },
      {
        property: "og:description",
        content:
          "Trusted online vape store since 2021. Genuine disposable vapes and nicotine pouches, shipped Australia-wide in 3–5 days.",
      },
      { property: "og:image", content: site.hero },
      { name: "twitter:image", content: site.hero },
    ],
  }),
  component: Index,
});

const topPicks = [
  "iget-one-12000",
  "iget-bar-pro-10000",
  "iget-bar-plus-s3-10000",
  "iget-bar-plus-s3-pod-only-10000",
  "alibarbar-ice-adjust-12000",
  "alibarbar-ingot-9000",
  "alibarbar-ingot-15000",
  "alibarbar-ingot-30000",
  "alibarbar-upload-25000-puffs",
  "gunnpod-moss-8000",
];

const extraSections = [
  {
    title: "PUNKAPES",
    href: "/vape/punkapes",
    desc: "Discover PUNKAPES disposable vapes in Australia, with the Ultra, Ultra Pro and 6000 puff series offering bold flavour and dependable performance.",
  },
  {
    title: "HQD CUVIE SLICK 6000 PUFFS",
    href: "/vape/hqd",
    desc: "The HQD Cuvie Slick 6000 Puffs is a slim, pocket-friendly disposable vape delivering smooth, consistent flavour for Australian adult vapers.",
  },
  {
    title: "KUZ LUX 9000 PUFFS",
    href: "/vape/kuz",
    desc: "KUZ LUX 9000 Puffs combines a strong battery with rich flavour delivery, available at Australian Vapers with fast nationwide shipping.",
  },
  {
    title: "BULK VAPE",
    href: "/bulk-vape",
    desc: "Save more with bulk vape packs. Buy 3, 5 or 10-piece bundles of the most popular disposable vapes and get better value per device.",
  },
];

function Index() {
  const catalog = useCatalog();
  return (
    <main>
      <section className="bg-background py-8 text-center">
        <div className="mx-auto max-w-[1100px] px-4">
          <h1 className="text-2xl font-bold leading-tight md:text-[34px]">{site.heading}</h1>
          <p className="mt-3 text-sm text-muted-foreground md:text-base">{site.tagline}</p>
        </div>
      </section>

      <Link to="/bulk-vape" className="block">
        <img src={site.hero} alt="Massive sale up to 30% off — shop bulk vapes" className="w-full" />
      </Link>

      <section className="border-y border-border bg-background py-6">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center justify-center gap-x-10 gap-y-5 px-4">
          {badges.map((b) => (
            <div key={b.title + b.sub} className="flex items-center gap-3">
              <img src={b.img} alt="" className="h-10 w-10 object-contain" loading="lazy" />
              <div className="text-left">
                <p className="text-sm font-bold">{b.title}</p>
                <p className="text-xs text-muted-foreground">{b.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1280px] px-4 py-12">
        <h2 className="text-center text-2xl font-bold md:text-3xl">
          Top Disposable Vapes By Customer
        </h2>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {topPicks.map((slug) => {
            const c = catalog.catBySlug.get(slug);
            if (!c) return null;
            return (
              <Link key={slug} to={catalog.categoryPath(c)} className="group text-center">
                {c.image?.src ? (
                  <img
                    src={c.image.src}
                    alt={c.name}
                    loading="lazy"
                    className="aspect-square w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                ) : null}
                <p className="mt-3 text-sm font-semibold group-hover:text-sale">{c.name}</p>
              </Link>
            );
          })}
        </div>
      </section>

      {[...homeSections, ...extraSections].map((section) => {
        const slug = section.href.split("/").filter(Boolean).pop()!;
        const list = catalog.productsInCategory(slug).slice(0, 5);
        if (!list.length) return null;
        return (
          <section key={section.href} className="mx-auto max-w-[1280px] px-4 py-10">
            <h2 className="text-center text-2xl font-bold uppercase">
              <Link to={section.href} className="hover:text-sale">
                {section.title}
              </Link>
            </h2>
            <p className="mx-auto mt-4 max-w-5xl text-center text-sm leading-relaxed text-muted-foreground">
              {section.desc}
            </p>
            <div className="mt-8">
              <ProductGrid products={list} />
            </div>
            <div className="mt-6 text-center">
              <Link
                to={section.href}
                className="inline-block rounded-md bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:opacity-90"
              >
                View all
              </Link>
            </div>
          </section>
        );
      })}

      <section className="mx-auto max-w-[1280px] px-4 py-12">
        <h2 className="text-center text-2xl font-bold uppercase">
          <Link to="/nicotine-pouches" className="hover:text-sale">
            Shop Nicotine Pouches
          </Link>
        </h2>
        <div className="mt-8 grid grid-cols-2 gap-6 md:grid-cols-4">
          {catalog.childCategories("nicotine-pouches").map((c) => (
            <Link key={c.id} to={catalog.categoryPath(c)} className="group text-center">
              {c.image?.src ? (
                <img
                  src={c.image.src}
                  alt={c.name}
                  loading="lazy"
                  className="aspect-square w-full object-cover"
                />
              ) : null}
              <p className="mt-3 text-sm font-bold group-hover:text-sale">{c.name}</p>
              <p className="text-xs text-muted-foreground">{c.count} Products</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-muted py-14">
        <div className="mx-auto max-w-[900px] px-4">
          <h2 className="text-center text-2xl font-bold">About Australian Vapers</h2>
          <p className="mt-5 text-sm leading-relaxed">
            <strong>
              Australian Vapers is a trusted online vape store in Australia, founded in 2021. We
              specialize in premium disposable vapes, pod systems, and nicotine pouches.
            </strong>{" "}
            All products are sourced directly from verified manufacturers and delivered
            factory-sealed. Every item undergoes strict quality control to ensure authenticity and
            consistent performance.
          </p>
          <p className="mt-4 text-sm leading-relaxed">
            We provide fast, discreet Australia-wide delivery. Orders reach customers in{" "}
            <strong>Melbourne, Sydney, Brisbane, Perth, Adelaide, Hobart, Darwin or Canberra</strong>
            , and all other states within 3–5 business days.
          </p>
          <p className="mt-4 text-sm leading-relaxed">
            Our catalogue features trending flavours with responsive local support. We maintain high
            standards of quality, reliability, and customer satisfaction across Australia.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[1000px] px-4 py-14">
        <h2 className="text-center text-2xl font-bold">Why Choose Australian Vapers in Australia?</h2>
        <p className="mt-5 text-sm leading-relaxed">
          Australian Vapers is a trusted online vape shop for adults, offering genuine disposable
          vapes and premium nicotine pouches. We prioritize authenticity, safety, and customer
          confidence, stocking top brands like IGET, ALIBARBAR, GUNNPOD, KUZ, HQD, and PUNKAPES. Our
          catalogue is regularly updated to showcase the latest trends and popular flavours in
          Australia's vaping market.
        </p>
        <h3 className="mt-8 text-lg font-bold">Our Unique Strengths:</h3>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-sm">
          <li>
            Authentic Products Only: factory-sealed devices sourced directly from verified and
            approved manufacturers.
          </li>
          <li>
            Fast, Trackable Nationwide Delivery: discreet, reliable shipping supported by real-time
            tracking.
          </li>
          <li>
            Secure Adult Checkout: responsible age verification and encrypted payments to ensure
            safe access for adults.
          </li>
          <li>
            Premium Global Vape Brands: a curated lineup from leading names trusted for performance,
            flavour accuracy, and durability.
          </li>
          <li>
            Dedicated Customer Support: responsive 24/7 assistance from a team that understands the
            standards and expectations of Australian vapers.
          </li>
        </ul>
        <p className="mt-6 text-sm italic">
          Note: Dear customers, due to a high volume of orders, if your selection includes
          unavailable flavours, we will contact you via email or SMS to arrange a replacement. If we
          do not receive a response within 2 days, random flavours will be selected for your order.
          Thank you for your understanding.
        </p>
      </section>

      <section className="bg-muted py-14">
        <div className="mx-auto max-w-[1280px] px-4">
          <h2 className="text-center text-2xl font-bold">Good Reviews From Real Buyers</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {reviews.map((r) => (
              <div key={r.name} className="rounded-lg bg-background p-6 shadow-sm">
                <h3 className="font-bold">{r.name}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{r.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[900px] px-4 py-14">
        <h2 className="text-center text-2xl font-bold">FAQs</h2>
        <div className="mt-6 divide-y divide-border border-y border-border">
          {homeFaqs.map((f) => (
            <details key={f.q} className="group py-4">
              <summary className="cursor-pointer list-none text-sm font-semibold">{f.q}</summary>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>
    </main>
  );
}
