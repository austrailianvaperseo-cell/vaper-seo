import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import blogRaw from "@/data/blog.json";

type Post = {
  slug: string;
  title: string;
  date: string;
  excerpt: string;
  html: string;
  image: string | null;
};
const posts = blogRaw as Post[];

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = posts.find((p) => p.slug === params.slug);
    if (!post) throw notFound();
    return { title: post.title, image: post.image };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Article unavailable" }, { name: "robots", content: "noindex" }] };
    }
    const title = `${loaderData.title} | Australian Vapers`;
    const description = `${loaderData.title} — vaping guide and review from Australian Vapers.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        ...(loaderData.image
          ? [
              { property: "og:image", content: loaderData.image },
              { name: "twitter:image", content: loaderData.image },
            ]
          : []),
      ],
    };
  },
  component: BlogPost,
});

function BlogPost() {
  const { slug } = Route.useParams();
  const post = posts.find((p) => p.slug === slug)!;
  return (
    <main className="mx-auto max-w-[860px] px-4 py-12">
      <nav className="text-xs text-muted-foreground">
        <Link to="/" className="hover:text-sale">
          Home
        </Link>{" "}
        /{" "}
        <Link to="/blog" className="hover:text-sale">
          Blog
        </Link>
      </nav>
      <h1 className="mt-4 text-3xl font-bold leading-tight">{post.title}</h1>
      <p className="mt-2 text-xs text-muted-foreground">
        {new Date(post.date).toLocaleDateString("en-AU", {
          day: "numeric",
          month: "long",
          year: "numeric",
        })}
      </p>
      {post.image ? (
        <img src={post.image} alt={post.title} className="mt-6 w-full object-cover" />
      ) : null}
      <div className="wp-content mt-8" dangerouslySetInnerHTML={{ __html: post.html }} />
    </main>
  );
}
