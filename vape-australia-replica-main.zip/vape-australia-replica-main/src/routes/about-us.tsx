import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/about-us")({
  head: () => ({
    meta: [
      { title: "About Us | Australian Vapers" },
      {
        name: "description",
        content:
          "Australian Vapers is Australia's trusted online vape shop since 2021, delivering 100% genuine disposable vapes and nicotine pouches.",
      },
      { property: "og:title", content: "About Us | Australian Vapers" },
      { property: "og:description", content: "Who we are and why Aussie vapers trust us since 2021." },
    ],
  }),
  component: () => <StaticPage slug="about-us" />,
});
