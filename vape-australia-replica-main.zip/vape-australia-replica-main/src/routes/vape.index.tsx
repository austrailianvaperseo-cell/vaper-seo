import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/vape/")({
  head: () => ({
    meta: [
      { title: "Disposable Vapes Australia | Australian Vapers" },
      {
        name: "description",
        content:
          "Shop genuine disposable vapes in Australia from IGET, ALIBARBAR, GUNNPOD, HQD, KUZ and PUNKAPES with fast nationwide delivery.",
      },
      { property: "og:title", content: "Disposable Vapes Australia | Australian Vapers" },
      {
        property: "og:description",
        content: "Verified disposable vapes shipped Australia-wide in 3–5 business days.",
      },
    ],
  }),
  component: () => <CategoryPage slug="vape" />,
});
