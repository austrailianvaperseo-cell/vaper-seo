import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin, useSession, ADMIN_EMAIL } from "@/lib/admin";
import {
  fetchDbCategories,
  fetchDbProducts,
  type DbCategory,
  type DbProduct,
} from "@/lib/db-products";
import { uploadProductImage } from "@/lib/upload";
import { defaultSettings, type SiteSettings } from "@/lib/settings";
import { fetchPaymentMethods } from "@/lib/payment-methods";
import { useOrders, setOrderStatus, deleteOrder } from "@/lib/orders";
import { useDailyVisits } from "@/lib/analytics";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip as RTooltip,
  XAxis,
  YAxis,
} from "recharts";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin Panel | Australian Vapers" },
      { name: "description", content: "Manage products, categories, branding and contact details." },
      { property: "og:title", content: "Admin Panel | Australian Vapers" },
      { property: "og:description", content: "Store administration for Australian Vapers." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

const emptyProduct = {
  slug: "",
  name: "",
  price: "0",
  regular_price: "",
  images: [] as string[],
  categories: [] as string[],
  flavors: "",
  description: "",
  in_stock: true,
  hidden: false,
};
type Draft = typeof emptyProduct;

const input = "w-full rounded-md border border-border px-3 py-2 text-sm";
const label = "block text-xs font-semibold uppercase tracking-wide text-muted-foreground";

function slugify(v: string) {
  return v
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function Admin() {
  const navigate = useNavigate();
  const { session, loading } = useSession();
  const { isAdmin, checking } = useIsAdmin(session);
  const [tab, setTab] = useState<
    "dashboard" | "orders" | "products" | "categories" | "payments" | "site" | "contact"
  >("dashboard");

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/auth" });
  }, [loading, session, navigate]);

  if (loading || checking || !session) {
    return <main className="mx-auto max-w-3xl px-4 py-20 text-sm">Loading…</main>;
  }

  if (!isAdmin) {
    return (
      <main className="mx-auto max-w-xl px-4 py-20">
        <h1 className="text-2xl font-bold">Access denied</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          This area is restricted to {ADMIN_EMAIL}. You are signed in as {session.user.email}.
        </p>
        <button
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/auth", replace: true });
          }}
          className="mt-6 rounded-md border border-border px-4 py-2 text-sm font-semibold"
        >
          Sign out
        </button>
      </main>
    );
  }

  const nav = [
    ["dashboard", "Dashboard"],
    ["orders", "Orders"],
    ["products", "Products"],
    ["categories", "Categories"],
    ["payments", "Payment methods"],
    ["site", "Website name & logo"],
    ["contact", "Contact & channels"],
  ] as const;

  return (
    <main className="mx-auto max-w-[1400px] px-4 py-8">
      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside className="h-fit rounded-lg border border-border p-4 lg:sticky lg:top-4">
          <h1 className="px-2 text-lg font-bold">Admin panel</h1>
          <nav className="mt-4 flex flex-wrap gap-1 lg:flex-col">
            {nav.map(([k, text]) => (
              <button
                key={k}
                onClick={() => setTab(k)}
                className={`rounded-md px-3 py-2 text-left text-sm font-semibold transition-colors ${
                  tab === k
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-accent"
                }`}
              >
                {text}
              </button>
            ))}
          </nav>
          <div className="mt-6 space-y-2 border-t border-border pt-4 text-sm">
            <Link to="/" className="block px-3 hover:underline">
              View store
            </Link>
            <button
              onClick={async () => {
                await supabase.auth.signOut();
                navigate({ to: "/auth", replace: true });
              }}
              className="w-full rounded-md border border-border px-3 py-1.5 font-semibold"
            >
              Sign out
            </button>
          </div>
        </aside>

        <section className="min-w-0">
          {tab === "dashboard" ? (
            <DashboardTab />
          ) : tab === "orders" ? (
            <OrdersTab />
          ) : tab === "products" ? (
            <ProductsTab />
          ) : tab === "categories" ? (
            <CategoriesTab />
          ) : tab === "payments" ? (
            <PaymentMethodsTab />
          ) : (
            <SettingsTab section={tab} />
          )}
        </section>
      </div>
    </main>
  );
}

function money(n: number) {
  return `$${Number(n || 0).toFixed(2)}`;
}

function DashboardTab() {
  const { data: orders = [], isLoading } = useOrders();
  const [range, setRange] = useState(30);
  const { data: visits = [] } = useDailyVisits(range);

  const today = new Date().toISOString().slice(0, 10);
  const monthStart = today.slice(0, 8) + "01";
  const revenue = orders.reduce((n, o) => n + Number(o.total), 0);
  const newOrders = orders.filter((o) => o.status === "new");
  const monthOrders = orders.filter((o) => o.created_at.slice(0, 10) >= monthStart);
  const visitsToday = visits.find((v) => v.day === today)?.visits ?? 0;
  const visitsRange = visits.reduce((n, v) => n + v.visits, 0);

  const cards = [
    ["Total orders", String(orders.length)],
    ["New orders", String(newOrders.length)],
    ["Orders this month", String(monthOrders.length)],
    ["Total revenue", money(revenue)],
    ["Visits today", String(visitsToday)],
    [`Visits (last ${range} days)`, String(visitsRange)],
  ];

  return (
    <div>
      <h2 className="text-xl font-bold">Dashboard</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {cards.map(([t, v]) => (
          <div key={t} className="rounded-lg border border-border p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {t}
            </p>
            <p className="mt-1 text-2xl font-bold">{v}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-lg border border-border p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-bold">Website traffic</h3>
          <div className="flex gap-1">
            {[7, 30, 180].map((d) => (
              <button
                key={d}
                onClick={() => setRange(d)}
                className={`rounded-md px-3 py-1 text-xs font-semibold ${
                  range === d ? "bg-primary text-primary-foreground" : "border border-border"
                }`}
              >
                {d === 7 ? "7 days" : d === 30 ? "30 days" : "6 months"}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-4 h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={visits}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
              <XAxis dataKey="day" tick={{ fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={32} />
              <RTooltip />
              <Area
                type="monotone"
                dataKey="visits"
                stroke="hsl(var(--primary))"
                fill="hsl(var(--primary))"
                fillOpacity={0.18}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        {!visits.length ? (
          <p className="mt-2 text-xs text-muted-foreground">
            No visits recorded yet — traffic starts counting from now.
          </p>
        ) : null}
      </div>

      <div className="mt-8">
        <h3 className="font-bold">Latest orders</h3>
        {isLoading ? (
          <p className="mt-2 text-sm text-muted-foreground">Loading…</p>
        ) : !orders.length ? (
          <p className="mt-2 text-sm text-muted-foreground">No orders yet.</p>
        ) : (
          <div className="mt-3 overflow-x-auto rounded-lg border border-border">
            <table className="w-full text-left text-sm">
              <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-3 py-2">Order</th>
                  <th className="px-3 py-2">Customer</th>
                  <th className="px-3 py-2">Email</th>
                  <th className="px-3 py-2">Total</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {orders.slice(0, 8).map((o) => (
                  <tr key={o.id}>
                    <td className="px-3 py-2 font-semibold">{o.order_number}</td>
                    <td className="px-3 py-2">{o.customer_name}</td>
                    <td className="px-3 py-2">{o.email}</td>
                    <td className="px-3 py-2">{money(o.total)}</td>
                    <td className="px-3 py-2 capitalize">{o.status}</td>
                    <td className="px-3 py-2">{new Date(o.created_at).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function OrdersTab() {
  const qc = useQueryClient();
  const { data: orders = [], isLoading } = useOrders();
  const [open, setOpen] = useState<string | null>(null);
  const [filter, setFilter] = useState("all");

  const shown = orders.filter((o) => filter === "all" || o.status === filter);
  const refresh = () => qc.invalidateQueries({ queryKey: ["orders"] });

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-xl font-bold">Orders</h2>
        <div className="flex gap-1">
          {["all", "new", "processing", "completed", "cancelled"].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`rounded-md px-3 py-1 text-xs font-semibold capitalize ${
                filter === s ? "bg-primary text-primary-foreground" : "border border-border"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <p className="mt-4 text-sm text-muted-foreground">Loading…</p>
      ) : !shown.length ? (
        <p className="mt-4 text-sm text-muted-foreground">No orders here yet.</p>
      ) : (
        <div className="mt-4 space-y-3">
          {shown.map((o) => (
            <div key={o.id} className="rounded-lg border border-border p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold">
                    {o.order_number} — {money(o.total)}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {o.customer_name} · {o.email} · {new Date(o.created_at).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={o.status}
                    onChange={async (e) => {
                      await setOrderStatus(o.id, e.target.value);
                      refresh();
                    }}
                    className="rounded-md border border-border px-2 py-1 text-xs capitalize"
                  >
                    {["new", "processing", "completed", "cancelled"].map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => setOpen(open === o.id ? null : o.id)}
                    className="rounded-md border border-border px-3 py-1 text-xs font-semibold"
                  >
                    {open === o.id ? "Hide" : "Details"}
                  </button>
                  <button
                    onClick={async () => {
                      if (!confirm(`Delete order ${o.order_number}?`)) return;
                      await deleteOrder(o.id);
                      refresh();
                    }}
                    className="rounded-md border border-border px-3 py-1 text-xs font-semibold text-destructive"
                  >
                    Delete
                  </button>
                </div>
              </div>

              {open === o.id ? (
                <div className="mt-4 grid gap-4 border-t border-border pt-4 text-sm sm:grid-cols-2">
                  <div>
                    <p className="font-semibold">Customer</p>
                    <p className="mt-1 whitespace-pre-line text-muted-foreground">
                      {o.customer_name}
                      {"\n"}
                      {o.email}
                      {"\n"}
                      {o.phone}
                      {"\n"}
                      {o.address}, {o.suburb} {o.state} {o.postcode}
                    </p>
                    <p className="mt-2 text-muted-foreground">
                      Payment: {o.payment_method || "—"}
                    </p>
                    {o.notes ? (
                      <p className="mt-2 text-muted-foreground">Notes: {o.notes}</p>
                    ) : null}
                  </div>
                  <div>
                    <p className="font-semibold">Items</p>
                    <ul className="mt-1 space-y-1 text-muted-foreground">
                      {(o.items ?? []).map((it, i) => (
                        <li key={`${it.slug}-${i}`} className="flex justify-between gap-3">
                          <span>
                            {it.name} × {it.qty}
                          </span>
                          <span>{money(it.price * it.qty)}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="mt-2 flex justify-between font-semibold">
                      <span>Total</span>
                      <span>{money(o.total)}</span>
                    </p>
                  </div>
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ImageUploader({
  images,
  onChange,
}: {
  images: string[];
  onChange: (next: string[]) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  return (
    <div>
      <span className={label}>Product photos</span>
      <div className="mt-2 flex flex-wrap gap-2">
        {images.map((src) => (
          <div key={src} className="relative">
            <img src={src} alt="" className="h-20 w-20 rounded border border-border object-cover" />
            <button
              type="button"
              onClick={() => onChange(images.filter((i) => i !== src))}
              className="absolute -right-2 -top-2 h-6 w-6 rounded-full border border-border bg-background text-xs font-bold"
              aria-label="Remove photo"
            >
              ×
            </button>
          </div>
        ))}
      </div>
      <input
        type="file"
        accept="image/*"
        multiple
        disabled={busy}
        onChange={async (e) => {
          const files = Array.from(e.target.files ?? []);
          e.target.value = "";
          if (!files.length) return;
          setBusy(true);
          setErr("");
          try {
            const urls: string[] = [];
            for (const f of files) urls.push(await uploadProductImage(f));
            onChange([...images, ...urls]);
          } catch (e2) {
            setErr((e2 as Error).message);
          } finally {
            setBusy(false);
          }
        }}
        className="mt-3 block w-full text-sm"
      />
      <p className="mt-1 text-xs text-muted-foreground">
        {busy ? "Uploading…" : "The first photo is used as the main product image."}
      </p>
      {err ? <p className="text-xs text-sale">{err}</p> : null}
    </div>
  );
}

function ProductsTab() {
  const qc = useQueryClient();
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["admin-products"],
    queryFn: fetchDbProducts,
  });
  const { data: cats = [] } = useQuery({
    queryKey: ["admin-categories"],
    queryFn: fetchDbCategories,
  });
  const [draft, setDraft] = useState<Draft>(emptyProduct);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const [newCat, setNewCat] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const perPage = 20;

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? rows.filter((r) => r.name.toLowerCase().includes(t) || r.slug.includes(t)) : rows;
  }, [rows, q]);
  const pages = Math.max(1, Math.ceil(filtered.length / perPage));
  const current = Math.min(page, pages);
  const shown = filtered.slice((current - 1) * perPage, current * perPage);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-products"] });
    qc.invalidateQueries({ queryKey: ["admin-categories"] });
    qc.invalidateQueries({ queryKey: ["catalog"] });
  };

  const addCategory = useMutation({
    mutationFn: async (name: string) => {
      const slug = slugify(name);
      const { error } = await supabase
        .from("categories")
        .upsert({ slug, name }, { onConflict: "slug" });
      if (error) throw new Error(error.message);
      return slug;
    },
    onSuccess: (slug) => {
      setNewCat("");
      setDraft((d) => ({ ...d, categories: [...new Set([...d.categories, slug])] }));
      invalidate();
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const save = useMutation({
    mutationFn: async () => {
      const flavors = draft.flavors
        .split(",")
        .map((f) => f.trim())
        .filter(Boolean);
      const payload = {
        slug: draft.slug.trim(),
        name: draft.name.trim(),
        price: Number(draft.price) || 0,
        regular_price: draft.regular_price ? Number(draft.regular_price) : null,
        image: draft.images[0] ?? null,
        images: draft.images,
        category_slug: draft.categories[0] ?? null,
        category_slugs: draft.categories,
        flavors,
        description: draft.description,
        in_stock: draft.in_stock,
        hidden: draft.hidden,
      };
      const res = editingId
        ? await supabase.from("products").update(payload).eq("id", editingId)
        : await supabase.from("products").insert(payload);
      if (res.error) throw new Error(res.error.message);
    },
    onSuccess: () => {
      setMsg(editingId ? "Product updated." : "Product added.");
      setDraft(emptyProduct);
      setEditingId(null);
      invalidate();
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("products").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setMsg("Product deleted.");
      invalidate();
    },
    onError: (e: Error) => setMsg(e.message),
  });

  function edit(p: DbProduct) {
    setEditingId(p.id);
    setMsg("");
    setDraft({
      slug: p.slug,
      name: p.name,
      price: String(p.price),
      regular_price: p.regular_price == null ? "" : String(p.regular_price),
      images: p.images?.length ? p.images : p.image ? [p.image] : [],
      categories: p.category_slugs?.length
        ? p.category_slugs
        : p.category_slug
          ? [p.category_slug]
          : [],
      flavors: (p.flavors ?? []).join(", "),
      description: p.description ?? "",
      in_stock: p.in_stock,
      hidden: p.hidden,
    });
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[400px_1fr]">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setMsg("");
          save.mutate();
        }}
        className="space-y-3 rounded-lg border border-border p-4"
      >
        <h2 className="text-lg font-bold">{editingId ? "Edit product" : "Add new product"}</h2>
        <div>
          <span className={label}>Name</span>
          <input
            required
            className={input}
            value={draft.name}
            onChange={(e) =>
              setDraft({
                ...draft,
                name: e.target.value,
                slug: editingId || draft.slug ? draft.slug : slugify(e.target.value),
              })
            }
          />
        </div>
        <div>
          <span className={label}>URL slug</span>
          <input
            required
            className={input}
            value={draft.slug}
            onChange={(e) => setDraft({ ...draft, slug: e.target.value })}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <span className={label}>Price (AUD)</span>
            <input
              required
              type="number"
              step="0.01"
              className={input}
              value={draft.price}
              onChange={(e) => setDraft({ ...draft, price: e.target.value })}
            />
          </div>
          <div>
            <span className={label}>Was price</span>
            <input
              type="number"
              step="0.01"
              className={input}
              value={draft.regular_price}
              onChange={(e) => setDraft({ ...draft, regular_price: e.target.value })}
            />
          </div>
        </div>

        <ImageUploader images={draft.images} onChange={(images) => setDraft({ ...draft, images })} />

        <div>
          <span className={label}>Categories</span>
          <div className="mt-2 max-h-44 overflow-auto rounded-md border border-border p-2 text-sm">
            {cats.map((c) => (
              <label key={c.slug} className="flex items-center gap-2 py-0.5">
                <input
                  type="checkbox"
                  checked={draft.categories.includes(c.slug)}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      categories: e.target.checked
                        ? [...draft.categories, c.slug]
                        : draft.categories.filter((s) => s !== c.slug),
                    })
                  }
                />
                {c.name}
              </label>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            <input
              className={input}
              placeholder="New category name"
              value={newCat}
              onChange={(e) => setNewCat(e.target.value)}
            />
            <button
              type="button"
              disabled={!newCat.trim() || addCategory.isPending}
              onClick={() => addCategory.mutate(newCat.trim())}
              className="whitespace-nowrap rounded-md border border-border px-3 py-2 text-sm font-semibold disabled:opacity-50"
            >
              Add
            </button>
          </div>
        </div>

        <div>
          <span className={label}>Flavours (comma separated)</span>
          <input
            className={input}
            placeholder="Blue Razz, Watermelon Ice, Mango"
            value={draft.flavors}
            onChange={(e) => setDraft({ ...draft, flavors: e.target.value })}
          />
        </div>

        <div>
          <span className={label}>Description</span>
          <textarea
            rows={4}
            className={input}
            value={draft.description}
            onChange={(e) => setDraft({ ...draft, description: e.target.value })}
          />
        </div>
        <div className="flex gap-4 text-sm">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={draft.in_stock}
              onChange={(e) => setDraft({ ...draft, in_stock: e.target.checked })}
            />
            In stock
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={draft.hidden}
              onChange={(e) => setDraft({ ...draft, hidden: e.target.checked })}
            />
            Hidden
          </label>
        </div>
        <div className="flex gap-2">
          <button
            disabled={save.isPending}
            className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
          >
            {editingId ? "Save changes" : "Add product"}
          </button>
          {editingId ? (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setDraft(emptyProduct);
              }}
              className="rounded-md border border-border px-4 py-2 text-sm font-semibold"
            >
              Cancel
            </button>
          ) : null}
        </div>
        {msg ? <p className="text-sm text-muted-foreground">{msg}</p> : null}
      </form>

      <div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-bold">All products ({filtered.length})</h2>
          <input
            className="w-56 rounded-md border border-border px-3 py-2 text-sm"
            placeholder="Search products"
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
          />
        </div>
        {isLoading ? <p className="mt-4 text-sm">Loading…</p> : null}
        <ul className="mt-4 divide-y divide-border">
          {shown.map((p) => (
            <li key={p.id} className="flex items-center gap-3 py-3">
              {p.image ? (
                <img src={p.image} alt={p.name} className="h-12 w-12 rounded object-cover" />
              ) : (
                <div className="h-12 w-12 rounded bg-muted" />
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{p.name}</p>
                <p className="text-xs text-muted-foreground">
                  ${Number(p.price).toFixed(2)} · {p.in_stock ? "In stock" : "Out of stock"}
                  {p.hidden ? " · Hidden" : ""}
                </p>
              </div>
              <button
                onClick={() => edit(p)}
                className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold"
              >
                Edit
              </button>
              <button
                onClick={() => remove.mutate(p.id)}
                className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold text-sale"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
        {pages > 1 ? (
          <div className="mt-6 flex items-center gap-3 text-sm">
            <button
              onClick={() => setPage(Math.max(1, current - 1))}
              className="rounded-md border border-border px-3 py-1.5 font-semibold"
            >
              Previous
            </button>
            <span>
              Page {current} of {pages}
            </span>
            <button
              onClick={() => setPage(Math.min(pages, current + 1))}
              className="rounded-md border border-border px-3 py-1.5 font-semibold"
            >
              Next
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );
}

const emptyCategory = { slug: "", name: "", parent_slug: "", description: "", image: "" };

function CategoriesTab() {
  const qc = useQueryClient();
  const { data: cats = [] } = useQuery({
    queryKey: ["admin-categories"],
    queryFn: fetchDbCategories,
  });
  const [draft, setDraft] = useState(emptyCategory);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [msg, setMsg] = useState("");
  const [q, setQ] = useState("");

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["admin-categories"] });
    qc.invalidateQueries({ queryKey: ["catalog"] });
  };

  const save = useMutation({
    mutationFn: async () => {
      const payload = {
        slug: draft.slug.trim() || slugify(draft.name),
        name: draft.name.trim(),
        parent_slug: draft.parent_slug || null,
        description: draft.description,
        image: draft.image || null,
      };
      const res = editingId
        ? await supabase.from("categories").update(payload).eq("id", editingId)
        : await supabase.from("categories").insert(payload);
      if (res.error) throw new Error(res.error.message);
    },
    onSuccess: () => {
      setMsg(editingId ? "Category updated." : "Category added.");
      setDraft(emptyCategory);
      setEditingId(null);
      invalidate();
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("categories").delete().eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setMsg("Category deleted.");
      invalidate();
    },
    onError: (e: Error) => setMsg(e.message),
  });

  function edit(c: DbCategory) {
    setEditingId(c.id);
    setMsg("");
    setDraft({
      slug: c.slug,
      name: c.name,
      parent_slug: c.parent_slug ?? "",
      description: c.description ?? "",
      image: c.image ?? "",
    });
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const term = q.trim().toLowerCase();
  const list = term ? cats.filter((c) => c.name.toLowerCase().includes(term)) : cats;

  return (
    <div className="grid gap-10 lg:grid-cols-[400px_1fr]">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setMsg("");
          save.mutate();
        }}
        className="space-y-3 rounded-lg border border-border p-4"
      >
        <h2 className="text-lg font-bold">{editingId ? "Edit category" : "Add new category"}</h2>
        <div>
          <span className={label}>Name</span>
          <input
            required
            className={input}
            value={draft.name}
            onChange={(e) =>
              setDraft({
                ...draft,
                name: e.target.value,
                slug: editingId || draft.slug ? draft.slug : slugify(e.target.value),
              })
            }
          />
        </div>
        <div>
          <span className={label}>URL slug</span>
          <input
            required
            className={input}
            value={draft.slug}
            onChange={(e) => setDraft({ ...draft, slug: e.target.value })}
          />
        </div>
        <div>
          <span className={label}>Parent category</span>
          <select
            className={input}
            value={draft.parent_slug}
            onChange={(e) => setDraft({ ...draft, parent_slug: e.target.value })}
          >
            <option value="">None (top level)</option>
            {cats.map((c) => (
              <option key={c.slug} value={c.slug}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <ImageUploader
          images={draft.image ? [draft.image] : []}
          onChange={(imgs) => setDraft({ ...draft, image: imgs[0] ?? "" })}
        />
        <div>
          <span className={label}>Description</span>
          <textarea
            rows={3}
            className={input}
            value={draft.description}
            onChange={(e) => setDraft({ ...draft, description: e.target.value })}
          />
        </div>
        <div className="flex gap-2">
          <button
            disabled={save.isPending}
            className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
          >
            {editingId ? "Save changes" : "Add category"}
          </button>
          {editingId ? (
            <button
              type="button"
              onClick={() => {
                setEditingId(null);
                setDraft(emptyCategory);
              }}
              className="rounded-md border border-border px-4 py-2 text-sm font-semibold"
            >
              Cancel
            </button>
          ) : null}
        </div>
        {msg ? <p className="text-sm text-muted-foreground">{msg}</p> : null}
      </form>

      <div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-bold">All categories ({list.length})</h2>
          <input
            className="w-56 rounded-md border border-border px-3 py-2 text-sm"
            placeholder="Search categories"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <ul className="mt-4 divide-y divide-border">
          {list.map((c) => (
            <li key={c.id} className="flex items-center gap-3 py-3">
              {c.image ? (
                <img src={c.image} alt={c.name} className="h-12 w-12 rounded object-cover" />
              ) : (
                <div className="h-12 w-12 rounded bg-muted" />
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{c.name}</p>
                <p className="text-xs text-muted-foreground">
                  /{c.slug}
                  {c.parent_slug ? ` · under ${c.parent_slug}` : ""}
                </p>
              </div>
              <button
                onClick={() => edit(c)}
                className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold"
              >
                Edit
              </button>
              <button
                onClick={() => remove.mutate(c.id)}
                className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold text-sale"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function SettingsTab({ section }: { section: "site" | "contact" }) {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin-settings"],
    queryFn: async (): Promise<SiteSettings> => {
      const { data } = await supabase.from("site_settings").select("*").maybeSingle();
      return (data as SiteSettings | null) ?? defaultSettings;
    },
  });
  const [form, setForm] = useState<SiteSettings | null>(null);
  const [msg, setMsg] = useState("");
  const value = form ?? data ?? defaultSettings;

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("site_settings").update(value).eq("id", true);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      setMsg("Saved.");
      qc.invalidateQueries({ queryKey: ["admin-settings"] });
      qc.invalidateQueries({ queryKey: ["site-settings"] });
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const set = (k: keyof SiteSettings, v: string) => setForm({ ...value, [k]: v });

  const fields: [keyof SiteSettings, string][] =
    section === "site"
      ? [
          ["site_name", "Website name"],
          ["logo_url", "Logo image URL"],
        ]
      : [
          ["contact_email", "Contact email"],
          ["support_email", "Support email"],
          ["phone", "Phone number"],
          ["address", "Business address"],
          ["telegram_channel_url", "Telegram channel link"],
          ["telegram_url", "Telegram support chat link"],
          ["whatsapp_url", "WhatsApp link"],
        ];

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        setMsg("");
        save.mutate();
      }}
      className="max-w-xl space-y-4"
    >
      {section === "site" ? (
        <ImageUploader
          images={value.logo_url ? [value.logo_url] : []}
          onChange={(imgs) => set("logo_url", imgs[0] ?? "")}
        />
      ) : null}
      {fields.map(([key, text]) => (
        <div key={key}>
          <span className={label}>{text}</span>
          <input
            className={input}
            value={value[key] ?? ""}
            onChange={(e) => set(key, e.target.value)}
          />
        </div>
      ))}
      <button
        disabled={save.isPending}
        className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
      >
        Save
      </button>
      {msg ? <p className="text-sm text-muted-foreground">{msg}</p> : null}
    </form>
  );
}

const emptyMethod = {
  name: "",
  description: "",
  instructions: "",
  active: true,
  sort_order: "0",
};
type MethodDraft = typeof emptyMethod;

function PaymentMethodsTab() {
  const qc = useQueryClient();
  const { data: methods = [] } = useQuery({
    queryKey: ["payment-methods", false],
    queryFn: () => fetchPaymentMethods(false),
  });
  const [draft, setDraft] = useState<MethodDraft>(emptyMethod);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [msg, setMsg] = useState("");

  const reset = () => {
    setDraft(emptyMethod);
    setEditingId(null);
  };

  const save = useMutation({
    mutationFn: async () => {
      const row = {
        name: draft.name.trim(),
        description: draft.description,
        instructions: draft.instructions,
        active: draft.active,
        sort_order: Number(draft.sort_order) || 0,
      };
      if (!row.name) throw new Error("Name is required");
      const { error } = editingId
        ? await supabase.from("payment_methods").update(row).eq("id", editingId)
        : await supabase.from("payment_methods").insert(row);
      if (error) throw error;
    },
    onSuccess: () => {
      setMsg(editingId ? "Payment method updated." : "Payment method added.");
      reset();
      qc.invalidateQueries({ queryKey: ["payment-methods"] });
    },
    onError: (e: Error) => setMsg(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("payment_methods").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      setMsg("Payment method deleted.");
      qc.invalidateQueries({ queryKey: ["payment-methods"] });
    },
  });

  return (
    <div className="grid gap-10 lg:grid-cols-[380px_1fr]">
      <form
        className="h-fit space-y-4 rounded-lg border border-border p-5"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <h2 className="text-lg font-bold">
          {editingId ? "Edit payment method" : "New payment method"}
        </h2>
        <div>
          <span className={label}>Name</span>
          <input
            className={input}
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="Direct bank transfer"
          />
        </div>
        <div>
          <span className={label}>Short description</span>
          <input
            className={input}
            value={draft.description}
            onChange={(e) => setDraft({ ...draft, description: e.target.value })}
            placeholder="Shown under the option at checkout"
          />
        </div>
        <div>
          <span className={label}>Payment instructions</span>
          <textarea
            rows={4}
            className={input}
            value={draft.instructions}
            onChange={(e) => setDraft({ ...draft, instructions: e.target.value })}
            placeholder="Bank name, BSB, account number…"
          />
        </div>
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={draft.active}
              onChange={(e) => setDraft({ ...draft, active: e.target.checked })}
            />
            Active
          </label>
          <label className="flex items-center gap-2 text-sm">
            Order
            <input
              type="number"
              className="w-20 rounded-md border border-border px-2 py-1 text-sm"
              value={draft.sort_order}
              onChange={(e) => setDraft({ ...draft, sort_order: e.target.value })}
            />
          </label>
        </div>
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={save.isPending}
            className="rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"
          >
            {editingId ? "Save changes" : "Add method"}
          </button>
          {editingId ? (
            <button
              type="button"
              onClick={reset}
              className="rounded-md border border-border px-4 py-2 text-sm font-semibold"
            >
              Cancel
            </button>
          ) : null}
        </div>
        {msg ? <p className="text-xs text-muted-foreground">{msg}</p> : null}
      </form>

      <div className="space-y-3">
        {methods.map((m) => (
          <div key={m.id} className="rounded-lg border border-border p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-semibold">
                  {m.name}{" "}
                  {!m.active ? (
                    <span className="ml-2 rounded bg-muted px-2 py-0.5 text-xs">Inactive</span>
                  ) : null}
                </p>
                {m.description ? (
                  <p className="mt-1 text-sm text-muted-foreground">{m.description}</p>
                ) : null}
              </div>
              <div className="flex gap-2 text-sm">
                <button
                  onClick={() => {
                    setEditingId(m.id);
                    setDraft({
                      name: m.name,
                      description: m.description,
                      instructions: m.instructions,
                      active: m.active,
                      sort_order: String(m.sort_order),
                    });
                  }}
                  className="rounded-md border border-border px-3 py-1.5 font-semibold"
                >
                  Edit
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete ${m.name}?`)) remove.mutate(m.id);
                  }}
                  className="rounded-md border border-border px-3 py-1.5 font-semibold text-destructive"
                >
                  Delete
                </button>
              </div>
            </div>
            {m.instructions ? (
              <p className="mt-2 whitespace-pre-line text-xs text-muted-foreground">
                {m.instructions}
              </p>
            ) : null}
          </div>
        ))}
        {!methods.length ? (
          <p className="text-sm text-muted-foreground">No payment methods yet.</p>
        ) : null}
      </div>
    </div>
  );
}
