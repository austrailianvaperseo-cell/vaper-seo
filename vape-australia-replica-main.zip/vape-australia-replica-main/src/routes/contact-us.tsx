import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/contact-us")({
  head: () => ({
    meta: [
      { title: "Contact Us | Australian Vapers" },
      { name: "description", content: "Get in touch with the Australian Vapers support team about orders, delivery or products." },
      { property: "og:title", content: "Contact Us | Australian Vapers" },
      { property: "og:description", content: "Reach our Australian support team 24/7." },
    ],
  }),
  component: () => <StaticPage slug="contact-us" />,
});
