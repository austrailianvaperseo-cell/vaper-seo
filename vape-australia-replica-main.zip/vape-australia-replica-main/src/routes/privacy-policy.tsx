import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy | Australian Vapers" },
      { name: "description", content: "How Australian Vapers collects, uses and protects your personal information." },
      { property: "og:title", content: "Privacy Policy | Australian Vapers" },
      { property: "og:description", content: "Our approach to your data and privacy." },
    ],
  }),
  component: () => <StaticPage slug="privacy-policy" />,
});
