import { createFileRoute } from "@tanstack/react-router";
import { StaticPage } from "@/components/StaticPage";

export const Route = createFileRoute("/terms-conditions")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions | Australian Vapers" },
      { name: "description", content: "The terms and conditions that apply when shopping with Australian Vapers." },
      { property: "og:title", content: "Terms & Conditions | Australian Vapers" },
      { property: "og:description", content: "Terms governing use of the Australian Vapers store." },
    ],
  }),
  component: () => <StaticPage slug="terms-conditions" />,
});
