import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/nicotine-pouches/")({
  head: () => ({
    meta: [
      { title: "Nicotine Pouches Australia | ZYN, VELO, KILLA, PABLO" },
      {
        name: "description",
        content:
          "Shop nicotine pouches in Australia — ZYN, VELO, KILLA and PABLO — with genuine stock and fast, discreet delivery.",
      },
      { property: "og:title", content: "Nicotine Pouches Australia | Australian Vapers" },
      {
        property: "og:description",
        content: "Genuine ZYN, VELO, KILLA and PABLO nicotine pouches shipped Australia-wide.",
      },
    ],
  }),
  component: () => <CategoryPage slug="nicotine-pouches" />,
});
