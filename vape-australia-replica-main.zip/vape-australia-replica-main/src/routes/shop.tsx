import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { type Product } from "@/lib/catalog";
import { ProductGrid } from "@/components/ProductCard";
import { useCatalog } from "@/lib/db-products";

export const Route = createFileRoute("/shop")({
  validateSearch: (search: Record<string, unknown>): { s?: string } =>
    typeof search["s"] === "string" && search["s"] ? { s: search["s"] as string } : {},
  head: () => ({
    meta: [
      { title: "Shop All Vapes & Nicotine Pouches | Australian Vapers" },
      {
        name: "description",
        content:
          "Browse the full Australian Vapers catalogue: disposable vapes, pods and nicotine pouches with fast Australia-wide delivery.",
      },
      { property: "og:title", content: "Shop All Vapes & Nicotine Pouches | Australian Vapers" },
      {
        property: "og:description",
        content: "Every disposable vape and nicotine pouch we stock, in one place.",
      },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { s } = Route.useSearch();
  const [page, setPage] = useState(1);
  const perPage = 24;

  const catalog = useCatalog();
  const list: Product[] = s ? catalog.searchProducts(s) : catalog.products;
  const pages = Math.max(1, Math.ceil(list.length / perPage));
  const current = Math.min(page, pages);
  const shown = list.slice((current - 1) * perPage, current * perPage);

  return (
    <main className="mx-auto max-w-[1280px] px-4 py-10">
      <h1 className="text-center text-3xl font-bold">{s ? `Search results for "${s}"` : "Shop"}</h1>
      <p className="mt-2 text-center text-sm text-muted-foreground">
        Showing {shown.length} of {list.length} products
      </p>
      <div className="mt-8">
        <ProductGrid products={shown} />
      </div>
      {pages > 1 ? (
        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {Array.from({ length: pages }).slice(0, 30).map((_, i) => (
            <button
              key={i}
              onClick={() => {
                setPage(i + 1);
                if (typeof window !== "undefined") window.scrollTo({ top: 0 });
              }}
              className={`h-9 w-9 rounded-md border text-sm ${
                current === i + 1
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border hover:bg-accent"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      ) : null}
    </main>
  );
}
