import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";
import { catBySlug } from "@/lib/catalog";

export const Route = createFileRoute("/vape/$")({
  loader: ({ params }) => {
    const slug = params._splat?.split("/").filter(Boolean).pop() ?? "vape";
    const cat = catBySlug.get(slug);
    return { slug, name: cat?.name ?? "Disposable Vapes" };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.name ?? "Disposable Vapes";
    const title = `${name} | Australian Vapers`;
    const description = `Buy ${name} online in Australia. Genuine, factory-sealed stock with fast, trackable Australia-wide delivery.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
    };
  },
  component: VapeCategory,
});

function VapeCategory() {
  const { slug } = Route.useLoaderData();
  return <CategoryPage slug={slug} />;
}
