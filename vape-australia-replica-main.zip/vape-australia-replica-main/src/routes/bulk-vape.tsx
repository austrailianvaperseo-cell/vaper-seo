import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/bulk-vape")({
  head: () => ({
    meta: [
      { title: "Bulk Vape Packs Australia | Australian Vapers" },
      {
        name: "description",
        content:
          "Buy vapes in bulk and save. 3, 5 and 10-piece disposable vape bundles with better value per device and fast Australian delivery.",
      },
      { property: "og:title", content: "Bulk Vape Packs Australia | Australian Vapers" },
      { property: "og:description", content: "Multi-pack disposable vape bundles at wholesale-style pricing." },
    ],
  }),
  component: () => <CategoryPage slug="bulk-vape" />,
});
