import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { trackOrder, type TrackedOrder } from "@/lib/track-order.functions";


export const Route = createFileRoute("/track-order")({
  head: () => ({
    meta: [
      { title: "Track Your Order | Australian Vapers" },
      {
        name: "description",
        content:
          "Track your Australian Vapers order with your order number and billing email. Australia Post tracking on every parcel.",
      },
      { property: "og:title", content: "Track Your Order | Australian Vapers" },
      { property: "og:description", content: "Check the shipping status of your vape order." },
    ],
  }),
  component: Track,
});

const field =
  "mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-ring";

const STATUS_LABEL: Record<string, string> = {
  new: "Order received",
  processing: "Being packed",
  completed: "Shipped / completed",
  cancelled: "Cancelled",
};

function Track() {
  const track = useServerFn(trackOrder);
  const [orderNumber, setOrderNumber] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [order, setOrder] = useState<TrackedOrder | null>(null);

  return (
    <main className="mx-auto max-w-[700px] px-4 py-12">
      <h1 className="text-3xl font-bold">Track your order</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        To track your order please enter your order ID in the box below and press the "Track" button.
        This was given to you on your receipt and in the confirmation email you should have received.
      </p>
      <form
        className="mt-6"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          setMsg("");
          setOrder(null);
          try {
            const res = await track({ data: { orderNumber, email } });
            if (res.found) setOrder(res.order);
            else
              setMsg(
                "We couldn't find that order. Please check your order ID and the billing email you used at checkout.",
              );
          } catch {
            setMsg("Something went wrong looking up your order. Please try again in a moment.");
          } finally {
            setBusy(false);
          }
        }}
      >
        <label className="block text-sm">
          Order ID
          <input
            required
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
            placeholder="Found in your order confirmation email"
            className={field}
          />
        </label>
        <label className="mt-4 block text-sm">
          Billing email
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email you used during checkout"
            className={field}
          />
        </label>
        <button
          disabled={busy}
          className="mt-5 rounded-md bg-primary px-6 py-2.5 text-sm font-bold uppercase text-primary-foreground disabled:opacity-60"
        >
          {busy ? "Checking..." : "Track"}
        </button>
      </form>

      {msg ? <p className="mt-5 border border-border bg-muted p-4 text-sm">{msg}</p> : null}

      {order ? (
        <section className="mt-6 rounded-md border border-border p-5">
          <h2 className="text-lg font-bold">Order {order.order_number}</h2>
          <p className="mt-1 text-sm">
            Status:{" "}
            <span className="font-semibold">
              {STATUS_LABEL[order.status] ?? order.status}
            </span>
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Placed {new Date(order.created_at).toLocaleDateString()} · {order.payment_method}
          </p>
          {order.address ? (
            <p className="mt-1 text-sm text-muted-foreground">Delivering to {order.address}</p>
          ) : null}
          <ul className="mt-4 space-y-1 text-sm">
            {order.items.map((it) => (
              <li key={it.slug} className="flex justify-between gap-4">
                <span>
                  {it.name} × {it.qty}
                </span>
                <span>${(it.price * it.qty).toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <p className="mt-4 flex justify-between border-t border-border pt-3 text-sm font-bold">
            <span>Total</span>
            <span>${order.total.toFixed(2)}</span>
          </p>
        </section>
      ) : null}
    </main>
  );
}
