import { createFileRoute, Link } from "@tanstack/react-router";
import blogRaw from "@/data/blog.json";

export type Post = {
  slug: string;
  title: string;
  date: string;
  excerpt: string;
  html: string;
  image: string | null;
};
export const posts = blogRaw as Post[];

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Vaping Blog & Guides | Australian Vapers" },
      {
        name: "description",
        content:
          "Vape guides, flavour reviews and product comparisons from Australian Vapers — helping Aussie adults choose the right device.",
      },
      { property: "og:title", content: "Vaping Blog & Guides | Australian Vapers" },
      { property: "og:description", content: "Latest vape guides and reviews from Australian Vapers." },
    ],
  }),
  component: BlogIndex,
});

function BlogIndex() {
  return (
    <main className="mx-auto max-w-[1180px] px-4 py-12">
      <h1 className="text-3xl font-bold">Blog</h1>
      <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {posts.map((p) => (
          <article key={p.slug} className="border border-border">
            {p.image ? (
              <img src={p.image} alt={p.title} loading="lazy" className="aspect-[16/10] w-full object-cover" />
            ) : null}
            <div className="p-5">
              <p className="text-xs text-muted-foreground">
                {new Date(p.date).toLocaleDateString("en-AU", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </p>
              <h2 className="mt-2 text-base font-bold leading-snug">
                <Link to="/blog/$slug" params={{ slug: p.slug }} className="hover:text-sale">
                  {p.title}
                </Link>
              </h2>
              <div
                className="mt-3 line-clamp-4 text-sm text-muted-foreground"
                dangerouslySetInnerHTML={{ __html: p.excerpt }}
              />
            </div>
          </article>
        ))}
      </div>
    </main>
  );
}
