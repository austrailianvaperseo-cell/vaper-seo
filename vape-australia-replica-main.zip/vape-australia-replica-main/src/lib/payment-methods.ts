import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type PaymentMethod = {
  id: string;
  name: string;
  description: string;
  instructions: string;
  active: boolean;
  sort_order: number;
};

export async function fetchPaymentMethods(onlyActive: boolean): Promise<PaymentMethod[]> {
  let q = supabase
    .from("payment_methods")
    .select("id, name, description, instructions, active, sort_order")
    .order("sort_order", { ascending: true })
    .order("name", { ascending: true });
  if (onlyActive) q = q.eq("active", true);
  const { data, error } = await q;
  if (error || !data) return [];
  return data as PaymentMethod[];
}

export function usePaymentMethods(onlyActive = true) {
  const { data } = useQuery({
    queryKey: ["payment-methods", onlyActive],
    queryFn: () => fetchPaymentMethods(onlyActive),
    staleTime: 60_000,
  });
  return data ?? [];
}
