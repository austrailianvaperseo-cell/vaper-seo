import React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface OrderItemData {
  name: string
  qty: number
  price: number
}

export interface OrderConfirmationProps {
  siteName?: string
  orderNumber?: string
  customerName?: string
  items?: OrderItemData[]
  total?: number
  paymentMethod?: string
  address?: string
}

const money = (n: number) => `$${Number(n || 0).toFixed(2)}`

const OrderConfirmation = ({
  siteName = 'Australian Vapers',
  orderNumber = '',
  customerName = '',
  items = [],
  total = 0,
  paymentMethod = '',
  address = '',
}: OrderConfirmationProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{`Your ${siteName} order ${orderNumber} is confirmed`}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Thanks for your order</Heading>
        <Text style={text}>
          {customerName ? `Hi ${customerName},` : 'Hi there,'} we&apos;ve received your order
          {orderNumber ? ` ${orderNumber}` : ''} at {siteName}. Here are the details.
        </Text>

        <Section style={card}>
          {items.map((it, i) => (
            <Text key={i} style={line}>
              {it.name} × {it.qty}
              {'  —  '}
              {money(it.price * it.qty)}
            </Text>
          ))}
          <Hr style={hr} />
          <Text style={totalLine}>Total: {money(total)}</Text>
        </Section>

        {paymentMethod ? <Text style={text}>Payment method: {paymentMethod}</Text> : null}
        {address ? <Text style={text}>Delivery address: {address}</Text> : null}

        <Text style={muted}>
          We&apos;ll email your tracking details once your parcel is dispatched with Australia
          Post.
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: OrderConfirmation,
  subject: (data: Record<string, any>) =>
    `Your order ${data['orderNumber'] ?? ''} is confirmed`.trim(),
  displayName: 'Order confirmation (buyer)',
  previewData: {
    siteName: 'Australian Vapers',
    orderNumber: 'AV123456',
    customerName: 'Jane Smith',
    items: [{ name: 'IGET Bar Plus', qty: 2, price: 29.95 }],
    total: 59.9,
    paymentMethod: 'Direct bank transfer',
    address: '12 George St, Sydney NSW 2000',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { padding: '24px', maxWidth: '560px' }
const h1 = { fontSize: '22px', margin: '0 0 12px', color: '#111111' }
const text = { fontSize: '14px', lineHeight: '22px', color: '#333333' }
const muted = { fontSize: '13px', lineHeight: '20px', color: '#666666' }
const card = {
  border: '1px solid #e5e5e5',
  borderRadius: '8px',
  padding: '16px',
  margin: '16px 0',
}
const line = { fontSize: '14px', margin: '4px 0', color: '#333333' }
const totalLine = { fontSize: '15px', fontWeight: 'bold' as const, color: '#111111', margin: '4px 0' }
const hr = { borderColor: '#e5e5e5', margin: '12px 0' }

export default OrderConfirmation
