import React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface NewOrderAdminProps {
  orderNumber?: string
  customerName?: string
  email?: string
  phone?: string
  address?: string
  paymentMethod?: string
  notes?: string
  items?: { name: string; qty: number; price: number }[]
  total?: number
}

const money = (n: number) => `$${Number(n || 0).toFixed(2)}`

const NewOrderAdmin = ({
  orderNumber = '',
  customerName = '',
  email = '',
  phone = '',
  address = '',
  paymentMethod = '',
  notes = '',
  items = [],
  total = 0,
}: NewOrderAdminProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{`New order ${orderNumber} — ${money(total)}`}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>New order received</Heading>
        <Text style={text}>
          Order <strong>{orderNumber}</strong> for <strong>{money(total)}</strong>.
        </Text>

        <Section style={card}>
          <Text style={line}>Customer: {customerName || '—'}</Text>
          <Text style={line}>Email: {email || '—'}</Text>
          <Text style={line}>Phone: {phone || '—'}</Text>
          <Text style={line}>Address: {address || '—'}</Text>
          <Text style={line}>Payment: {paymentMethod || '—'}</Text>
          {notes ? <Text style={line}>Notes: {notes}</Text> : null}
          <Hr style={hr} />
          {items.map((it, i) => (
            <Text key={i} style={line}>
              {it.name} × {it.qty} — {money(it.price * it.qty)}
            </Text>
          ))}
          <Hr style={hr} />
          <Text style={totalLine}>Total: {money(total)}</Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: NewOrderAdmin,
  subject: (data: Record<string, any>) => `New order ${data['orderNumber'] ?? ''}`.trim(),
  displayName: 'New order notification (admin)',
  previewData: {
    orderNumber: 'AV123456',
    customerName: 'Jane Smith',
    email: 'jane@example.com',
    phone: '0400 000 000',
    address: '12 George St, Sydney NSW 2000',
    paymentMethod: 'Direct bank transfer',
    items: [{ name: 'IGET Bar Plus', qty: 2, price: 29.95 }],
    total: 59.9,
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { padding: '24px', maxWidth: '560px' }
const h1 = { fontSize: '22px', margin: '0 0 12px', color: '#111111' }
const text = { fontSize: '14px', lineHeight: '22px', color: '#333333' }
const card = {
  border: '1px solid #e5e5e5',
  borderRadius: '8px',
  padding: '16px',
  margin: '16px 0',
}
const line = { fontSize: '14px', margin: '4px 0', color: '#333333' }
const totalLine = { fontSize: '15px', fontWeight: 'bold' as const, color: '#111111', margin: '4px 0' }
const hr = { borderColor: '#e5e5e5', margin: '12px 0' }

export default NewOrderAdmin
