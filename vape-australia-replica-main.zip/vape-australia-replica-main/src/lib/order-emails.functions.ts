import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const FALLBACK_ADMIN_EMAIL = "contact.autraillianvapers@gmail.com";

/**
 * Sends the buyer confirmation and the admin notification for an order that
 * already exists in the database. Only the order id is accepted — every detail
 * is read server-side, so nothing about the email can be forged by the browser.
 */
export const sendOrderEmails = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => z.object({ orderNumber: z.string().min(3).max(40) }).parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");

    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .select("*")
      .eq("order_number", data.orderNumber)
      .maybeSingle();
    if (error || !order) return { sent: false as const };

    const { data: settings } = await supabaseAdmin
      .from("site_settings")
      .select("contact_email, site_name")
      .maybeSingle();

    const adminEmail = settings?.contact_email || FALLBACK_ADMIN_EMAIL;
    const siteName = settings?.site_name || "Australian Vapers";

    const items = Array.isArray(order.items) ? (order.items as any[]) : [];
    const fullAddress = [order.address, order.suburb, order.state, order.postcode]
      .filter(Boolean)
      .join(", ");

    const shared = {
      orderNumber: order.order_number,
      customerName: order.customer_name,
      email: order.email,
      phone: order.phone,
      address: fullAddress,
      paymentMethod: order.payment_method,
      notes: order.notes,
      items,
      total: Number(order.total),
    };

    const results = await Promise.allSettled([
      order.email
        ? sendTemplateEmail("order-confirmation", order.email, {
            templateData: { ...shared, siteName },
            idempotencyKey: `order-confirmation-${order.id}`,
            replyTo: adminEmail,
          })
        : Promise.resolve({ sent: false as const }),
      sendTemplateEmail("new-order-admin", adminEmail, {
        templateData: shared,
        idempotencyKey: `new-order-admin-${order.id}`,
        replyTo: order.email || undefined,
      }),
    ]);

    for (const r of results) {
      if (r.status === "rejected") console.error("order email failed", r.reason);
    }

    return { sent: true as const };
  });
