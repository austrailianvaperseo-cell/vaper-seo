import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { site } from "@/lib/site";

export type SiteSettings = {
  site_name: string;
  logo_url: string;
  contact_email: string;
  support_email: string;
  phone: string;
  address: string;
  telegram_url: string;
  telegram_channel_url: string;
  whatsapp_url: string;
};

export const defaultSettings: SiteSettings = {
  site_name: site.name,
  logo_url: site.logo,
  contact_email: site.email,
  support_email: site.email,
  phone: "",
  address: site.address,
  telegram_url: "",
  telegram_channel_url: "",
  whatsapp_url: "",
};

export function useSettings(): SiteSettings {
  const { data } = useQuery({
    queryKey: ["site-settings"],
    queryFn: async (): Promise<SiteSettings> => {
      const { data, error } = await supabase
        .from("site_settings")
        .select(
          "site_name, logo_url, contact_email, support_email, phone, address, telegram_url, telegram_channel_url, whatsapp_url",
        )
        .maybeSingle();
      if (error || !data) return defaultSettings;
      return data as SiteSettings;
    },
    staleTime: 60_000,
  });

  return data ?? defaultSettings;
}
