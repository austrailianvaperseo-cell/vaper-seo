import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { makeCatalog, staticCatalog, type Catalog, type Category, type Product } from "@/lib/catalog";

export type DbProduct = {
  id: string;
  slug: string;
  name: string;
  price: number;
  regular_price: number | null;
  image: string | null;
  category_slug: string | null;
  category_slugs: string[] | null;
  flavors: string[] | null;
  images: string[] | null;
  description: string;
  in_stock: boolean;
  hidden: boolean;
  rating: number | null;
  sort_order: number | null;
};

export type DbCategory = {
  id: string;
  slug: string;
  name: string;
  parent_slug: string | null;
  description: string;
  image: string | null;
  sort_order: number | null;
};

export function toCatalogProduct(
  row: DbProduct,
  catNames?: Map<string, string>,
): Product {
  const price = Math.round(Number(row.price) * 100);
  const regular = Math.round(Number(row.regular_price ?? row.price) * 100);
  const slugs = row.category_slugs?.length
    ? row.category_slugs
    : row.category_slug
      ? [row.category_slug]
      : [];
  return {
    id: -1,
    name: row.name,
    slug: row.slug,
    price: String(price),
    regular: String(regular),
    sale: regular > price ? String(price) : "",
    md: 2,
    image: row.image,
    cats: slugs.map((s) => ({ name: catNames?.get(s) ?? s, slug: s })),
    stock: row.in_stock,
    rating: row.rating == null ? null : String(row.rating),
    count: 0,
    onsale: regular > price,
    description: row.description ?? "",
    images: row.images ?? [],
    flavors: row.flavors ?? [],
  };
}

export async function fetchDbProducts(): Promise<DbProduct[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false })
    .limit(2000);
  if (error) return [];
  return (data ?? []) as unknown as DbProduct[];
}

export async function fetchDbCategories(): Promise<DbCategory[]> {
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .order("sort_order", { ascending: true })
    .limit(1000);
  if (error) return [];
  return (data ?? []) as unknown as DbCategory[];
}

function buildCatalog(rows: DbProduct[], cats: DbCategory[]): Catalog {
  const idBySlug = new Map(cats.map((c, i) => [c.slug, i + 1]));
  const nameBySlug = new Map(cats.map((c) => [c.slug, c.name]));
  const visible = rows.filter((r) => !r.hidden);
  const products = visible.map((r) => toCatalogProduct(r, nameBySlug));

  const counts = new Map<string, number>();
  for (const p of products) {
    for (const c of p.cats) counts.set(c.slug, (counts.get(c.slug) ?? 0) + 1);
  }

  const categories: Category[] = cats.map((c, i) => ({
    id: i + 1,
    parent: c.parent_slug ? (idBySlug.get(c.parent_slug) ?? 0) : 0,
    name: c.name,
    slug: c.slug,
    count: counts.get(c.slug) ?? 0,
    description: c.description ?? "",
    image: c.image ? { src: c.image } : null,
  }));

  return makeCatalog(products, categories);
}

export function useCatalogQuery() {
  return useQuery({
    queryKey: ["catalog"],
    queryFn: async () => {
      const [rows, cats] = await Promise.all([fetchDbProducts(), fetchDbCategories()]);
      return { rows, cats };
    },
    staleTime: 60_000,
  });
}

/** Live catalog from the backend; falls back to the bundled snapshot until loaded. */
export function useCatalog(): Catalog {
  const { data } = useCatalogQuery();
  if (!data || data.rows.length === 0) return staticCatalog;
  return buildCatalog(data.rows, data.cats);
}
