export const site = {
  name: "Australian Vapers",
  logo: "https://vapersaustralia.com/wp-content/uploads/2025/11/australian-vapers-logo.webp",
  hero: "https://vapersaustralia.com/wp-content/uploads/2026/08/buy-bulk-vape-online.png",
  email: "contact.australianvapers@gmail.com",
  address: "122 Moore st, Liverpool NSW 2170",
  topBar: "By using Australian Vapers, you confirm that you are over 18 years old.",
  tagline: "Best Online Vape Store: Trusted by True Aussies",
  heading:
    "Australian Vapers – Trusted Disposable Vapes & Nicotine Pouches Store Online in Australia",
};

export const badges = [
  {
    img: "https://vapersaustralia.com/wp-content/uploads/2025/11/verified-retailer-australian-vapers.webp",
    title: "Verified Retailer",
    sub: "Since 2021",
  },
  {
    img: "https://vapersaustralia.com/wp-content/uploads/2025/11/fast-delivery-icon.webp",
    title: "Fast Delivery",
    sub: "Fast Australia-wide delivery",
  },
  {
    img: "https://vapersaustralia.com/wp-content/uploads/2025/11/best-quality-icon.webp",
    title: "100%",
    sub: "Genuine Products",
  },
  {
    img: "https://vapersaustralia.com/wp-content/uploads/2025/11/customer-service-icon.webp",
    title: "Customer Care",
    sub: "24/7 Service",
  },
  {
    img: "https://vapersaustralia.com/wp-content/uploads/2025/11/trackable-orders-icon.webp",
    title: "Trackable Orders",
    sub: "100% Delivered",
  },
  {
    img: "https://vapersaustralia.com/wp-content/uploads/2025/11/safe-and-easy-payment-icon.webp",
    title: "Secure Payments",
    sub: "100% Secure",
  },
];

export const nav = [
  { label: "About us", href: "/about-us" },
  {
    label: "IGET Vapes",
    href: "/vape/iget",
    children: [
      { label: "IGET ONE 12000", href: "/vape/iget/iget-one-12000" },
      { label: "IGET BAR PRO 10000", href: "/vape/iget/iget-bar-pro-10000" },
      { label: "IGET BAR PLUS S3 10000", href: "/vape/iget/iget-bar-plus-s3-10000" },
      {
        label: "IGET BAR PLUS S3 PODS 10000",
        href: "/vape/iget/iget-bar-plus-s3-pod-only-10000",
      },
      { label: "IGET BAR 3500", href: "/vape/iget/iget-bar-3500" },
      { label: "IGET MOON", href: "/vape/iget/iget-moon-k5000" },
      { label: "IGET HOT", href: "/vape/iget/iget-hot-5500" },
    ],
  },
  {
    label: "ALIBARBAR Vapes",
    href: "/vape/alibarbar",
    tag: "NEW",
    children: [
      { label: "ICE ADJUST 12000 PUFFS", href: "/vape/alibarbar/alibarbar-ice-adjust-12000" },
      { label: "INGOT 9000 PUFFS", href: "/vape/alibarbar/alibarbar-ingot-9000" },
      { label: "INGOT 15000 PUFFS", href: "/vape/alibarbar/alibarbar-ingot-15000" },
      { label: "INGOT 30000 PUFFS", href: "/vape/alibarbar/alibarbar-ingot-30000" },
      { label: "UPLOAD 25000 PUFFS", href: "/vape/alibarbar/alibarbar-upload-25000-puffs" },
      { label: "SWIRL 13000 PUFFS", href: "/vape/alibarbar/alibarbar-swirl-13000-puffs" },
    ],
  },
  {
    label: "Nicotine Pouches",
    href: "/nicotine-pouches",
    children: [
      { label: "KILLA NICOTINE POUCHES", href: "/nicotine-pouches/killa" },
      { label: "VELO NICOTINE POUCHES", href: "/nicotine-pouches/velo" },
      { label: "ZYN NICOTINE POUCHES", href: "/nicotine-pouches/zyn" },
      { label: "PABLO NICOTINE POUCHES", href: "/nicotine-pouches/pablo" },
    ],
  },
  { label: "Track Order", href: "/track-order" },
];

export const footerColumns = [
  {
    title: "About Us",
    links: [
      { label: "About Australian Vapers", href: "/about-us" },
      { label: "Our Team", href: "/team" },
      { label: "Shop", href: "/shop" },
    ],
  },
  {
    title: "Feature Series",
    links: [
      { label: "IGET", href: "/vape/iget" },
      { label: "ALIBARBAR Vapes", href: "/vape/alibarbar" },
      { label: "KUZ", href: "/vape/kuz" },
      { label: "GUNNPOD", href: "/vape/gunnpod" },
      { label: "HQD", href: "/vape/hqd" },
      { label: "PUNKAPES", href: "/vape/punkapes" },
      { label: "Nicotine Pouches", href: "/nicotine-pouches" },
    ],
  },
  {
    title: "Customer Policies",
    links: [
      { label: "Payment Methods", href: "/payment-methods" },
      { label: "Shipping Policy", href: "/shipping-policy" },
      { label: "Returns & Refunds Policy", href: "/returns-and-refunds" },
      { label: "Delivery Locations", href: "/delivery-locations" },
      { label: "Product Verification", href: "/product-verification" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "FAQs", href: "/faqs" },
      { label: "Contact Us", href: "/contact-us" },
      { label: "Track Your Order", href: "/track-order" },
      { label: "Blog", href: "/blog" },
    ],
  },
];

export const socials = [
  { label: "Facebook", href: "https://www.facebook.com/profile.php?id=61585907023961" },
  { label: "Instagram", href: "https://www.instagram.com/australianvapers/" },
  { label: "X", href: "https://x.com/australianvaper" },
  { label: "LinkedIn", href: "https://www.linkedin.com/in/australian-vapers-6b84a33a3/" },
  { label: "YouTube", href: "https://www.youtube.com/@australianvapers" },
];

export const homeFaqs = [
  {
    q: "How long does shipping take?",
    a: "Most orders arrive within 1–3 business days in metro areas and 3–7 business days in regional locations. Any order placed before 1 pm on a weekday is shipped out the same day for a faster delivery window.",
  },
  {
    q: "What payment methods do you accept?",
    a: "We currently accept secure payments via bank transfer and Visa/Mastercard. These trusted options ensure your checkout process is simple and safe.",
  },
  {
    q: "Do you offer discreet packaging?",
    a: "Yes, every order is packed in plain, unmarked packaging with no indication of what's inside. This ensures complete privacy from the moment it leaves our warehouse to when it reaches your door.",
  },
  {
    q: "How can I track my order?",
    a: "Your order is shipped through Australia Post, and tracking details are sent to your email or phone once it's dispatched. You can also check the order shipping status by inputting the order number at the bottom of our homepage.",
  },
  {
    q: "What should I do if my vape arrives damaged or not working?",
    a: "If your vape arrives faulty or damaged, contact us within 48 hours and include photos or videos of the issue. We'll arrange either a replacement or store credit based on the circumstances.",
  },
];

export const reviews = [
  {
    name: "JAMES T.",
    text: "First time ordering from Australian Vapers and I'm genuinely impressed. The IGET and Alibarbar disposables arrived in just 2 days, authentic and fresh. Much better prices than other places I've tried.",
  },
  {
    name: "EMMA R.",
    text: "Great prices and excellent quality. The products are 100% authentic with a huge variety of flavours from Punkape and GUNNPOD. Definitely the best value I've found for disposable vapes in Australia.",
  },
  {
    name: "DAVID K.",
    text: "Easy website, smooth checkout process, and very helpful support. They ship discreetly and securely, perfect for privacy. Will definitely be ordering again from Australian Vapers.",
  },
];
