import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type OrderItem = {
  slug: string;
  name: string;
  qty: number;
  price: number; // dollars, per unit
};

export type Order = {
  id: string;
  order_number: string;
  customer_name: string;
  email: string;
  phone: string;
  address: string;
  suburb: string;
  state: string;
  postcode: string;
  notes: string;
  payment_method: string;
  items: OrderItem[];
  total: number;
  status: string;
  created_at: string;
};

export type NewOrder = Omit<Order, "id" | "created_at" | "status">;

export async function createOrder(order: NewOrder): Promise<void> {
  // Anonymous shoppers may insert but not read orders, so no returning clause.
  const { error } = await supabase.from("orders").insert(order as never);
  if (error) throw error;
}

export async function fetchOrders(): Promise<Order[]> {
  const { data, error } = await supabase
    .from("orders")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) throw error;
  return (data ?? []) as unknown as Order[];
}

export function useOrders() {
  return useQuery({ queryKey: ["orders"], queryFn: fetchOrders, staleTime: 15_000 });
}

export async function setOrderStatus(id: string, status: string) {
  const { error } = await supabase.from("orders").update({ status } as never).eq("id", id);
  if (error) throw error;
}

export async function deleteOrder(id: string) {
  const { error } = await supabase.from("orders").delete().eq("id", id);
  if (error) throw error;
}
