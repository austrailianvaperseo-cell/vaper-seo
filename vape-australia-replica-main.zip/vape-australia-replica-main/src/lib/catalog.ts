import productsRaw from "@/data/products.json";
import categoriesRaw from "@/data/categories.json";
import homeSectionsRaw from "@/data/home-sections.json";

export type Product = {
  id: number;
  name: string;
  slug: string;
  price: string;
  regular: string;
  sale: string;
  md: number;
  image: string | null;
  cats: { name: string; slug: string }[];
  stock: boolean;
  rating: string | null;
  count: number;
  onsale: boolean;
  description?: string;
  images?: string[];
  flavors?: string[];
};

export type Category = {
  id: number;
  parent: number;
  name: string;
  slug: string;
  count: number;
  description?: string;
  image?: { src: string } | null;
};

export const products = productsRaw as Product[];
export const categories = categoriesRaw as unknown as Category[];
export const homeSections = homeSectionsRaw as {
  title: string;
  href: string;
  desc: string;
}[];

export function money(minor: string | number, md = 2) {
  const v = Number(minor) / Math.pow(10, md);
  return `$${v.toFixed(2)}`;
}

export function discount(p: Product) {
  const r = Number(p.regular);
  const s = Number(p.price);
  if (!r || s >= r) return 0;
  return Math.round(((r - s) / r) * 100);
}

export type Catalog = {
  products: Product[];
  categories: Category[];
  bySlug: Map<string, Product>;
  catBySlug: Map<string, Category>;
  productsInCategory: (slug: string) => Product[];
  childCategories: (parentSlug: string) => Category[];
  categoryPath: (cat: Category) => string;
  searchProducts: (q: string) => Product[];
};

export function makeCatalog(prods: Product[], cats: Category[]): Catalog {
  const bySlugMap = new Map(prods.map((p) => [p.slug, p]));
  const catBySlugMap = new Map(cats.map((c) => [c.slug, c]));
  const catById = new Map(cats.map((c) => [c.id, c]));

  const productsInCategory = (slug: string) => prods.filter((p) => p.cats.some((c) => c.slug === slug));

  return {
    products: prods,
    categories: cats,
    bySlug: bySlugMap,
    catBySlug: catBySlugMap,
    productsInCategory,
    childCategories: (parentSlug: string) => {
      const parent = catBySlugMap.get(parentSlug);
      if (!parent) return [];
      return cats.filter((c) => c.parent === parent.id);
    },
    categoryPath: (cat: Category) => {
      const chain: Category[] = [cat];
      let cur = cat;
      while (cur.parent) {
        const p = catById.get(cur.parent);
        if (!p) break;
        chain.unshift(p);
        cur = p;
      }
      return "/" + chain.map((c) => c.slug).join("/");
    },
    searchProducts: (q: string) => {
      const t = q.trim().toLowerCase();
      if (!t) return [];
      return prods
        .filter(
          (p) =>
            p.name.toLowerCase().includes(t) ||
            (p.flavors ?? []).some((f) => f.toLowerCase().includes(t)),
        )
        .slice(0, 60);
    },
  };
}

export const staticCatalog = makeCatalog(products, categories);

export const bySlug = staticCatalog.bySlug;
export const catBySlug = staticCatalog.catBySlug;
export const productsInCategory = staticCatalog.productsInCategory;
export const childCategories = staticCatalog.childCategories;
export const categoryPath = staticCatalog.categoryPath;
export const searchProducts = staticCatalog.searchProducts;
