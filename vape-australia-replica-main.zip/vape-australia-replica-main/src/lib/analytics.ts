import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export type DailyVisit = { day: string; visits: number };

/** Records one page view per route change (browser only, admin pages excluded). */
export function usePageViewTracker() {
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (path.startsWith("/admin") || path.startsWith("/auth")) return;
    void supabase
      .from("page_views")
      .insert({ path } as never)
      .then(() => undefined);
  }, [path]);
}

export function useDailyVisits(days = 30) {
  return useQuery({
    queryKey: ["daily-visits", days],
    queryFn: async (): Promise<DailyVisit[]> => {
      const { data, error } = await supabase.rpc("daily_visits" as never, { _days: days } as never);
      if (error) throw error;
      return ((data ?? []) as { day: string; visits: number }[]).map((r) => ({
        day: r.day,
        visits: Number(r.visits),
      }));
    },
    staleTime: 60_000,
  });
}
