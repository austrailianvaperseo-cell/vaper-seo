import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export type TrackedOrder = {
  order_number: string;
  status: string;
  created_at: string;
  customer_name: string;
  payment_method: string;
  address: string;
  total: number;
  items: { slug: string; name: string; qty: number; price: number }[];
};

export type TrackResult = { found: false } | { found: true; order: TrackedOrder };

/**
 * Looks up an order by its number plus the billing email used at checkout.
 * Read server-side so shoppers can only see their own order.
 */
export const trackOrder = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    z
      .object({
        orderNumber: z.string().trim().min(3).max(40),
        email: z.string().trim().email().max(200),
      })
      .parse(data),
  )
  .handler(async ({ data }): Promise<TrackResult> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .select(
        "order_number, status, created_at, customer_name, payment_method, address, suburb, state, postcode, email, total, items",
      )
      .ilike("order_number", data.orderNumber)
      .maybeSingle();

    if (error || !order) return { found: false };
    if ((order.email ?? "").trim().toLowerCase() !== data.email.toLowerCase()) {
      return { found: false };
    }

    return {
      found: true,
      order: {
        order_number: order.order_number,
        status: order.status ?? "new",
        created_at: order.created_at,
        customer_name: order.customer_name ?? "",
        payment_method: order.payment_method ?? "",
        address: [order.address, order.suburb, order.state, order.postcode]
          .filter(Boolean)
          .join(", "),
        total: Number(order.total),
        items: Array.isArray(order.items) ? (order.items as TrackedOrder["items"]) : [],
      },
    };
  });
